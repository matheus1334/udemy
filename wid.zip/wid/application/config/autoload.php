<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$autoload['packages'] = array();

$autoload['libraries'] = array('ion_auth', 'database', 'form_validation', 'session', 'pdf');

$autoload['drivers'] = array();

$autoload['helper'] = array('url', 'security', 'array', 'funcao', 'string', 'text');

$autoload['config'] = array();

$autoload['language'] = array();

$autoload['model'] = array('Core_model');
