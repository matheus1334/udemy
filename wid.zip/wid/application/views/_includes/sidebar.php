<!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

      <!-- Sidebar - Brand -->
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?php echo base_url('home'); ?>">
        <div class="sidebar-brand-icon rotate-n-15">
          <i class="fas fa-laugh-wink"></i>
        </div>
        <div class="sidebar-brand-text mx-3">WID</div>
      </a>

      <!-- Divider -->
      <hr class="sidebar-divider my-0">

      <!-- Nav Item - Dashboard -->
      <li class="nav-item">
        <a class="nav-link" href="<?php echo base_url('home'); ?>">
          <i class="fas fa-home"></i>
          <span>Dashboard</span></a>
      </li>

      <!-- Divider -->
      <hr class="sidebar-divider">

      <!-- Heading -->
      <div class="sidebar-heading">
        Módulos
      </div>
 		
 		
 		
	  <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseFive" aria-expanded="true" aria-controls="collapseFive">
          <i class="fas fa-shopping-cart"></i>
          <span>Vendas</span>
        </a>
        <div id="collapseFive" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Escolha uma opção:</h6>
         	 <a class="collapse-item" href="<?php echo base_url('os'); ?>"><i class="fas fa-shopping-basket"></i><span>&nbsp;&nbsp;Ordem de Serviço</span></a> 
         	 <a class="collapse-item" href="<?php echo base_url('vendas'); ?>"><i class="fas fa-shopping-cart"></i><span>&nbsp;&nbsp;Vendas</span></a> 
          </div>
        </div>
      </li>
      	
	  
     
       <!-- Nav Item - Pages Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseThree" aria-expanded="true" aria-controls="collapseThree">
          <i class="fas fa-database"></i>
          <span>Cadastros</span>
        </a>
        <div id="collapseThree" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Escolha uma opção:</h6>
         	 <a class="collapse-item" href="<?php echo base_url('cliente'); ?>"><i class="fas fa-user-tie"></i><span>&nbsp;&nbsp;Clientes</span></a>
         	 <a class="collapse-item" href="<?php echo base_url('fornecedor'); ?>"><i class="fas fa-user-tag"></i><span>&nbsp;&nbsp;Fornecedores</span></a>
         	 <a class="collapse-item" href="<?php echo base_url('vendedor'); ?>"><i class="fas fa-user"></i><span>&nbsp;&nbsp;Vendedores</span></a>
         	 <a class="collapse-item" href="<?php echo base_url('servico'); ?>"><i class="fas fa-laptop-house"></i><span>&nbsp;&nbsp;Serviços</span></a>
         	 
          </div>
        </div>
      </li>
      
      
      
       <!-- Nav Item - Pages Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
          <i class="fas fa-box-open"></i>
          <span>Estoques</span>
        </a>
        <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Escolha uma opção:</h6> 
         	 <a class="collapse-item" href="<?php echo base_url('marca'); ?>"><i class="fas fa-cubes"></i><span>&nbsp;&nbsp;Marcas</span></a>
         	 <a class="collapse-item" href="<?php echo base_url('produto'); ?>"><i class="fab fa-product-hunt"></i><span>&nbsp;&nbsp;Produtos</span></a>
         	 <a class="collapse-item" href="<?php echo base_url('categoria'); ?>"><i class="fab fa-buffer"></i><span>&nbsp;&nbsp;Categorias</span></a>
          </div>
        </div>
      </li>
      <!-- Nav Item - Pages Collapse Menu -->
     <?php if($this->ion_auth->is_admin()){ ?>
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseFour" aria-expanded="true" aria-controls="collapseFour">
          <i class="fas fa-coins"></i>
          <span>Financeiros</span>
        </a>
        <div id="collapseFour" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Escolha uma opção:</h6> 
         	 <a class="collapse-item" href="<?php echo base_url('pagar'); ?>"><i class="fas fa-money-bill-alt"></i><span>&nbsp;&nbsp;Contas à Pagar</span></a><a class="collapse-item" href="<?php echo base_url('receber'); ?>"><i class="fas fa-hand-holding-usd"></i><span>&nbsp;&nbsp;Contas à Receber</span></a>
         	 <a class="collapse-item" href="<?php echo base_url('modulo'); ?>"><i class="fas fa-money-check-alt"></i><span>&nbsp;&nbsp;Formas de Pagamento</span></a>
          </div>
        </div>
      </li>
      
      
      
      
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseSix" aria-expanded="true" aria-controls="collapseSix">
          <i class="fas fa-search-dollar"></i>
          <span>Relatórios</span>
        </a>
        <div id="collapseSix" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Escolha uma opção:</h6>
         	 <a class="collapse-item" href="<?php echo base_url('relatorios/vendas'); ?>"><i class="fas fa-shopping-cart"></i><span>&nbsp;&nbsp;Vendas</span></a> 
         	  <a class="collapse-item" href="<?php echo base_url('relatorios/os'); ?>"><i class="fas fa-shopping-basket"></i><span>&nbsp;&nbsp;Ordem de Serviço</span></a> 
         	  <a class="collapse-item" href="<?php echo base_url('relatorios/receber'); ?>"><i class="fas fa-hand-holding-usd"></i><span>&nbsp;&nbsp;A receber</span></a> 
         	  <a class="collapse-item" href="<?php echo base_url('relatorios/pagar'); ?>"><i class="fas fa-money-bill-alt"></i><span>&nbsp;&nbsp;A pagar</span></a> 
          </div>
        </div>
      </li>
      <?php } ?>
      <!-- Divider -->
      <hr class="sidebar-divider">

	  <?php if($this->ion_auth->is_admin()){ ?>
      <!-- Heading -->
      <div class="sidebar-heading">
       	Configurações 
      </div>

      <!-- Nav Item - Tables -->
      <li class="nav-item">
        <a class="nav-link" href="<?php echo base_url('usuario'); ?>">
          <i class="fas fa-users"></i>
          <span>Usuários</span></a>
      </li>

	  <li class="nav-item">
        <a class="nav-link" href="<?php echo base_url('sistema'); ?>">
          <i class="fas fa-cogs"></i>
          <span>Sistemas</span></a>
      </li>

      <!-- Divider -->
      <hr class="sidebar-divider d-none d-md-block">
      <?php } ?>

      <!-- Sidebar Toggler (Sidebar) -->
      <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
      </div>

    </ul>
    <!-- End of Sidebar -->
 	<!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">
