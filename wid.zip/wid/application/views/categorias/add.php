<style>
.font-small{
	font-size: 1em;
}
</style>


<?php $this->load->view('_includes/sidebar'); ?>
    
   
<!-- Main Content -->
<div id="content">

	<?php $this->load->view('_includes/topbar.php'); ?>


	<!-- Begin Page Content -->
	<div class="container-fluid">

	  <nav aria-label="breadcrumb">
		  <ol class="breadcrumb">
		    <li class="breadcrumb-item"><a href="<?php echo base_url('categoria'); ?>">Categorias</a></li>
		    <li class="breadcrumb-item active" aria-current="page"><?php echo $titulo; ?></li>
		  </ol>
		</nav>

          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <a href="<?php echo base_url('categoria'); ?>" class="btn btn-success btn-sm float-right"><i class="fas fa-arrow-left"></i>&nbsp; Voltar</a>
            </div>
            <div class="card-body">
              <form method="post" name="form_edit">
              <div class="form-group row">
              		
				    <div class="col-md-4">
				    	<select class="form-control" name="categoria_ativa">
				    		<option value="1">Ativo</option>
							<option value="2">Inativo</option>
				    	</select>
				    </div>
              	</div>
              	
              	
              	<fieldset class="mt-4 border p-3">
              		<legend class="font-small">Informações</legend>
              	
				  <div class="form-group row">
				    <div class="col-md-12">
				    	<labe>Título</labe>
				    	<input type="text" class="form-control" name="categoria_nome" placeholder="Título" value="<?php echo set_value('categoria_nome'); ?>">	
				    	<?php echo form_error('categoria_nome', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				  </div><!-- fim linha -->
				  
				</fieldset>
				
				
					<button type="submit" class="btn btn-primary btn-sm mt-4">Salvar</button>
				</form>
            </div>
          </div>

	</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->
