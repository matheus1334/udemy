<style>
.font-small{
	font-size: 1em;
}
</style>


<?php $this->load->view('_includes/sidebar'); ?>
    
   
<!-- Main Content -->
<div id="content">

	<?php $this->load->view('_includes/topbar.php'); ?>


	<!-- Begin Page Content -->
	<div class="container-fluid">

	  <nav aria-label="breadcrumb">
		  <ol class="breadcrumb">
		    <li class="breadcrumb-item"><a href="<?php echo base_url('produto'); ?>">Produtos</a></li>
		    <li class="breadcrumb-item active" aria-current="page"><?php echo $titulo; ?></li>
		  </ol>
		</nav>

          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <a href="<?php echo base_url('produto'); ?>" class="btn btn-success btn-sm float-right"><i class="fas fa-arrow-left"></i>&nbsp; Voltar</a>
            </div>
            <div class="card-body">
              <form method="post" name="form_edit">
              <div class="form-group row">
				    <div class="col-md-8">
              	<p><strong><i class="fas fa-clock"></i>&nbsp;&nbsp;Última alteração em: <?php echo formata_data_banco_com_hora($produtos->produto_data_alteracao); ?></strong></p>
              		</div>
              		
				    <div class="col-md-4">
				    	<select class="form-control" name="produto_ativo">
				    		<option value="1" <?php echo ($produtos->produto_ativo == 1) ? 'selected' : ''; ?>>Ativo</option>
							<option value="2" <?php echo ($produtos->produto_ativo == 2) ? 'selected' : ''; ?>>Inativo</option>
				    	</select>
				    </div>
              	</div>
              	
              	
              	<fieldset class="mt-4 border p-3">
              		<legend class="font-small">Dados do Produto</legend>
              	
				  <div class="form-group row">
				  
				    <div class="col-md-2">
				    	<labe>Codigo</labe>
				    	<input type="text" class="form-control" name="produto_codigo" placeholder="" value="<?php echo $produtos->produto_codigo; ?>" readonly="">	
				    	<?php echo form_error('produto_codigo', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				    <div class="col-md-10">
				    	<labe>Título</labe>
				    	<input type="text" class="form-control" name="produto_descricao" placeholder="Título" value="<?php echo $produtos->produto_descricao; ?>">	
				    	<?php echo form_error('produto_descricao', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				  
				  </div><!-- fim linha -->
				   
				   <div class="form-group row">
				  
				    <div class="col-md-3">
				    	<labe>Marca</labe>
				    	<select class="form-control" name="produto_marca_id">
				    		 <?php 
							 
							 	foreach($marcas as $marca){
							 		echo '
							 		<option title="'.($marca->marca_ativa == 2 ? 'Não pode ser escolhida' : 'Marca Ativa').'" value="'.$marca->marca_id.'"'.($marca->marca_id == $produtos->produto_marca_id ? 'selected' : $marca->marca_nome).' '.($marca->marca_ativa == 2 ? 'disabled' : '').' >'
							 		.($marca->marca_ativa == 2 ? $marca->marca_nome.'&nbsp; -> MARCA INATIVA' : $marca->marca_nome).'
							 		</option>';
							 	}
							 
							 ?>				    		
				    	</select>
				    </div>
				    <div class="col-md-3">
				    	<labe>Categoria</labe>
				    	<select class="form-control" name="produto_categoria_id">
							  <?php 
							 
							 	foreach($categorias as $categoria){
							 		echo '
							 		<option title="'.($categoria->categoria_ativa == 2 ? 'Não pode ser escolhida' : 'Categoria Ativa').'" value="'.$categoria->categoria_id.'"'.($categoria->categoria_id == $produtos->produto_categoria_id ? 'selected' : $categoria->categoria_nome).' '.($categoria->categoria_ativa == 2 ? 'disabled' : '').' >'
							 		.($categoria->categoria_ativa == 2 ? $categoria->categoria_nome.'&nbsp; -> CATEGORIA INATIVA' : $categoria->categoria_nome).'
							 		</option>';
							 	}
							 
							 ?>				    		
				    	</select>
				    </div>				  
				    <div class="col-md-3">
				    	<labe>Fornecedor</labe>
				    	<select class="form-control" name="produto_fornecedor_id">
							 <<?php 
							 
							 	foreach($fornecedores as $fornecedor){
							 		
							 		echo '
							 		<option title="'.($fornecedor->fornecedor_ativo == 2 ? 'Não pode ser escolhida' : 'Fornecedor Ativo').'" value="'.$fornecedor->fornecedor_id.'"'.($fornecedor->fornecedor_id == $produtos->produto_fornecedor_id ? 'selected' : $fornecedor->fornecedor_nome_fantasia).' '.($fornecedor->fornecedor_ativo == 2 ? 'disabled' : '').' >'
							 		.($fornecedor->fornecedor_ativo == 2 ? $fornecedor->fornecedor_nome_fantasia.'&nbsp; -> FORNECEDOR INATIVO' : $fornecedor->fornecedor_nome_fantasia).'
							 		</option>';
							 	}
							 
							 ?>				    		
				    	</select>
				    </div>
				    <div class="col-md-3">
				    	<labe>Unidade</labe>
				    	<select class="form-control" name="produto_fornecedor_id">

						<option value="UN">Unidade</option>
						<option value="CX">Caixa</option>
						<option value="CX">Mensalidade</option>			    		
				    	</select>
				    </div>
				  </div><!-- fim linha -->
				</fieldset>
				<fieldset class="mt-4 border p-3">
              		<legend class="font-small">Precificação e Estoque</legend>
              	
				  <div class="form-group row">
					    <div class="col-md-3">
					    	<labe>Preço de Custo</labe>
				    		<input type="text" class="form-control money" name="produto_preco_custo" placeholder="R$ Custo" value="<?php echo $produtos->produto_preco_custo; ?>">	
				    		<?php echo form_error('produto_preco_custo', '<small class="form-text text-danger">', '</small>'); ?>
					    </div> 
						<div class="col-md-3">
					    	<labe>Preço de Venda</labe>
				    		<input type="text" class="form-control money" name="produto_preco_venda" placeholder="R$ Venda" value="<?php echo $produtos->produto_preco_venda; ?>">	
				    		<?php echo form_error('produto_preco_venda', '<small class="form-text text-danger">', '</small>'); ?>
					    </div>
						<div class="col-md-3">
					    	<labe>Estoque Min</labe>
				    		<input type="text" class="form-control" name="produto_estoque_minimo" placeholder="Estoque Min" value="<?php echo $produtos->produto_estoque_minimo; ?>">	
				    		<?php echo form_error('produto_estoque_minimo', '<small class="form-text text-danger">', '</small>'); ?>
					    </div>
					    
						<div class="col-md-3">
					    	<labe>Estoque Atual</labe>
				    		<input type="text" class="form-control" name="produto_qtde_estoque" placeholder="Estoque Atual" value="<?php echo $produtos->produto_qtde_estoque; ?>">	
				    		<?php echo form_error('produto_qtde_estoque', '<small class="form-text text-danger">', '</small>'); ?>
					    </div>
					</div>
				</fieldset>
				
				<fieldset class="mt-4 border p-3">
              		<legend class="font-small">Precificação e Estoque</legend>
              	
					<div class="form-group row">
					    <div class="col-md-12">
					    	<labe>Observações</labe>
						<textarea class="form-control" name="produto_obs" placeholder="Observações"><?php echo $produtos->produto_obs; ?></textarea>	
						<?php echo form_error('produto_obs', '<small class="form-text text-danger">', '</small>'); ?>
					    </div> 
					</div>
				</fieldset>
				
					<input type="hidden" name="produto_id" value="<?php echo $produtos->produto_id; ?>"/>
					<button type="submit" class="btn btn-primary btn-sm mt-4">Salvar</button>
				</form>
            </div>
          </div>

	</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->
