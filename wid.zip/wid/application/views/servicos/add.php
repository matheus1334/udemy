<style>
.font-small{
	font-size: 1em;
}
</style>


<?php $this->load->view('_includes/sidebar'); ?>
    
   
<!-- Main Content -->
<div id="content">

	<?php $this->load->view('_includes/topbar.php'); ?>


	<!-- Begin Page Content -->
	<div class="container-fluid">

	  <nav aria-label="breadcrumb">
		  <ol class="breadcrumb">
		    <li class="breadcrumb-item"><a href="<?php echo base_url('servico'); ?>">Serviços</a></li>
		    <li class="breadcrumb-item active" aria-current="page"><?php echo $titulo; ?></li>
		  </ol>
		</nav>

          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <a href="<?php echo base_url('servico'); ?>" class="btn btn-success btn-sm float-right"><i class="fas fa-arrow-left"></i>&nbsp; Voltar</a>
            </div>
            <div class="card-body">
              <form method="post" name="form_edit">
              <div class="form-group row">
              		
				    <div class="col-md-4">
				    	<select class="form-control" name="servico_ativo">
				    		<option value="1">Ativo</option>
							<option value="2">Inativo</option>
				    	</select>
				    </div>
              	</div>
              	
              	
              	<fieldset class="mt-4 border p-3">
              		<legend class="font-small">Informações pessoais</legend>
              	
				  <div class="form-group row">
				    <div class="col-md-8">
				    	<labe>Título</labe>
				    	<input type="text" class="form-control" name="servico_nome" placeholder="Título" value="<?php echo set_value('servico_nome'); ?>">	
				    	<?php echo form_error('servico_nome', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				    <div class="col-md-4">
				    	<labe>Preço</labe>
				    	<input type="text" class="form-control money" name="servico_preco" placeholder="R$" value="<?php echo set_value('servico_preco'); ?>">	
				    	<?php echo form_error('servico_preco', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				  </div><!-- fim linha -->
				  
				</fieldset>
				
				
              	<fieldset class="mt-4 border p-3">
              		<legend class="font-small">Observações</legend>
              	
				   <div class="form-group row">
				     <div class="col-md-12">
				    	<textarea class="form-control" rows="3" name="servico_descricao" placeholder="Observação"><?php echo set_value('servico_descricao'); ?></textarea>	
				    	<?php echo form_error('servico_descricao', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				  </div><!-- fim linha -->
				</fieldset>
		
					<button type="submit" class="btn btn-primary btn-sm mt-4">Salvar</button>
				</form>
            </div>
          </div>

	</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->
