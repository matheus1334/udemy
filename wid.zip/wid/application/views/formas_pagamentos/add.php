<style>
.font-small{
	font-size: 1em;
}
</style>


<?php $this->load->view('_includes/sidebar'); ?>
    
   
<!-- Main Content -->
<div id="content">

	<?php $this->load->view('_includes/topbar.php'); ?>


	<!-- Begin Page Content -->
	<div class="container-fluid">

	  <nav aria-label="breadcrumb">
		  <ol class="breadcrumb">
		    <li class="breadcrumb-item"><a href="<?php echo base_url('formas_pagamentos'); ?>">Formas de Pagamento</a></li>
		    <li class="breadcrumb-item active" aria-current="page"><?php echo $titulo; ?></li>
		  </ol>
		</nav>

          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <a href="<?php echo base_url('formas_pagamentos'); ?>" class="btn btn-success btn-sm float-right"><i class="fas fa-arrow-left"></i>&nbsp; Voltar</a>
            </div>
            <div class="card-body">
              <form method="post" name="form_edit">
              <div class="form-group row">
				   
              		<div class="col-md-4">
				    	<select class="form-control" name="forma_pagamento_ativa">
				    		<option value="1">Ativo</option>
							<option value="2">Inativo</option>
				    	</select>
				    </div>
              	</div>
              	
              	
              	<fieldset class="mt-4 border p-3">
              		<legend class="font-small">Dados da Conta</legend>
              	
				
				   <div class="form-group row">
		  
				    <div class="col-md-6">
				    	<labe>Nome Forma</labe>
				    	<input type="text" class="form-control" name="forma_pagamento_nome" placeholder="Valor" value="<?php echo set_value('forma_pagamento_nome'); ?>">	
				    	<?php echo form_error('forma_pagamento_nome', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				    <div class="col-md-6">
				    	<labe>Aceita Parcelamento</labe>
				    	<select class="form-control" name="forma_pagamento_aceita_parc">
				    		<option value="1">Sim</option>
							<option value="2">Não</option>
				    	</select>
				    </div>
				
				  </div><!-- fim linha -->
				  
	
				  
				</fieldset>
						
					<button type="submit" class="btn btn-primary btn-sm mt-4">Salvar</button>
					
				</form>
            </div>
          </div>

	</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->
