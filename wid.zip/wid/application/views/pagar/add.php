<style>
.font-small{
	font-size: 1em;
}
</style>


<?php $this->load->view('_includes/sidebar'); ?>
    
   
<!-- Main Content -->
<div id="content">

	<?php $this->load->view('_includes/topbar.php'); ?>


	<!-- Begin Page Content -->
	<div class="container-fluid">

	  <nav aria-label="breadcrumb">
		  <ol class="breadcrumb">
		    <li class="breadcrumb-item"><a href="<?php echo base_url('pagar'); ?>">Contas a Pagar</a></li>
		    <li class="breadcrumb-item active" aria-current="page"><?php echo $titulo; ?></li>
		  </ol>
		</nav>

          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <a href="<?php echo base_url('pagar'); ?>" class="btn btn-success btn-sm float-right"><i class="fas fa-arrow-left"></i>&nbsp; Voltar</a>
            </div>
            <div class="card-body">
              <form method="post" name="form_add">
              	
              	
              	<fieldset class="mt-4 border p-3">
              		<legend class="font-small">Dados da Conta</legend>
              	
				
				   <div class="form-group row">
		  
				    <div class="col-md-4">
				    	<labe>Fornecedor</labe>
				    	<select class="custom-select contas_pagar" name="conta_pagar_fornecedor_id">
				    		<option value="" selected></option>
							 <?php 
							 
							 	foreach($fornecedores as $fornecedor){
							 		
							 		echo '
							 		<option value="'.$fornecedor->fornecedor_id.'">'.$fornecedor->fornecedor_nome_fantasia.'
							 		</option>';
							 	}
							 
							 ?>				    		
				    	</select>
				    	<?php echo form_error('conta_pagar_fornecedor_id', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				    <div class="col-md-3">
				    	<labe>Data Vencimento</labe>
				    	<input type="date" class="form-control" name="conta_pagar_data_vencto" placeholder="Data" value="<?php echo set_value('conta_pagar_data_vencto'); ?>">	
				    		<?php echo form_error('conta_pagar_data_vencto', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				    
				    <div class="col-md-3">
				    	<labe>Valor</labe>
				    	<input type="text" class="form-control money2" name="conta_pagar_valor" placeholder="Valor" value="<?php echo set_value('conta_pagar_valor'); ?>">	
				    		<?php echo form_error('conta_pagar_valor', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				    
				    <div class="col-md-2">
				    	<labe>Situação</labe>
				    	<select class="custom-select" name="conta_pagar_status">
							 <option value="0")>Pendente</option>
							 <option value="1">Paga</option>			    		
				    	</select>
				    	<?php echo form_error('conta_pagar_fornecedor_id', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				  </div><!-- fim linha -->
				  
				   <div class="form-group row">
				   	  <div class="col-md-12">
					   	  <labe>Observação</labe>
					   	  <textarea name="conta_pagar_obs" class="form-control" placeholder="Observação"><?php echo set_value('conta_pagar_obs'); ?></textarea>
					   	  <?php echo form_error('conta_pagar_obs', '<small class="form-text text-danger">', '</small>'); ?>
					   </div>
				   </div>
				  
				</fieldset>
						

				<button type="submit" class="btn btn-primary btn-sm mt-4">Salvar</button>

					
				</form>
            </div>
          </div>

	</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->
