<style>
.font-small{
	font-size: 1em;
}
</style>


<?php $this->load->view('_includes/sidebar'); ?>
    
   
<!-- Main Content -->
<div id="content">

	<?php $this->load->view('_includes/topbar.php'); ?>


	<!-- Begin Page Content -->
	<div class="container-fluid">

	  <nav aria-label="breadcrumb">
		  <ol class="breadcrumb">
		    <li class="breadcrumb-item"><a href="<?php echo base_url('pagar'); ?>">Contas a Pagar</a></li>
		    <li class="breadcrumb-item active" aria-current="page"><?php echo $titulo; ?></li>
		  </ol>
		</nav>

          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <a href="<?php echo base_url('pagar'); ?>" class="btn btn-success btn-sm float-right"><i class="fas fa-arrow-left"></i>&nbsp; Voltar</a>
            </div>
            <div class="card-body">
              <form method="post" name="form_edit">
              <div class="form-group row">
				    <div class="col-md-8">
              	<p><strong><i class="fas fa-clock"></i>&nbsp;&nbsp;Última alteração em: <?php echo formata_data_banco_com_hora($conta_pagar->conta_pagar_data_alteracao); ?></strong></p>
              		</div>
              		
              	</div>
              	
              	
              	<fieldset class="mt-4 border p-3">
              		<legend class="font-small">Dados da Conta</legend>
              	
				
				   <div class="form-group row">
		  
				    <div class="col-md-4">
				    	<labe>Fornecedor</labe>
				    	<select class="custom-select contas_pagar" name="conta_pagar_fornecedor_id">
							 <?php 
							 
							 	foreach($fornecedores as $fornecedor){
							 		
							 		echo '
							 		<option title="'.($fornecedor->fornecedor_ativo == 2 ? 'Não pode ser escolhida' : 'Fornecedor Ativo').'" value="'.$fornecedor->fornecedor_id.'"'.($fornecedor->fornecedor_id == $conta_pagar->conta_pagar_fornecedor_id ? 'selected' : $fornecedor->fornecedor_nome_fantasia).' '.($fornecedor->fornecedor_ativo == 2 ? 'disabled' : '').' >'
							 		.($fornecedor->fornecedor_ativo == 2 ? $fornecedor->fornecedor_nome_fantasia.'&nbsp; -> FORNECEDOR INATIVO' : $fornecedor->fornecedor_nome_fantasia).'
							 		</option>';
							 	}
							 
							 ?>				    		
				    	</select>
				    	<?php echo form_error('conta_pagar_fornecedor_id', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				    <div class="col-md-3">
				    	<labe>Data Vencimento</labe>
				    	<input type="date" class="form-control" name="conta_pagar_data_vencto" placeholder="Data" value="<?php echo $conta_pagar->conta_pagar_data_vencto; ?>">	
				    		<?php echo form_error('conta_pagar_data_vencto', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				    
				    <div class="col-md-3">
				    	<labe>Valor</labe>
				    	<input type="text" class="form-control money2" name="conta_pagar_valor" placeholder="Valor" value="<?php echo $conta_pagar->conta_pagar_valor; ?>">	
				    		<?php echo form_error('conta_pagar_valor', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				    
				    <div class="col-md-2">
				    	<labe>Situação</labe>
				    	<select class="custom-select" name="conta_pagar_status">
							 <?php 
							 
							 echo '<option value="0" '.($conta_pagar->conta_pagar_status == 0 ? 'selected' : '').'>Pendente</option>';
							 echo '<option value="1" '.($conta_pagar->conta_pagar_status == 1 ? 'selected' : '').'>Paga</option>';

							 ?>				    		
				    	</select>
				    	<?php echo form_error('conta_pagar_fornecedor_id', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				  </div><!-- fim linha -->
				  
				   <div class="form-group row">
				   	  <div class="col-md-12">
					   	  <labe>Observação</labe>
					   	  <textarea name="conta_pagar_obs" class="form-control" placeholder="Observação"><?php echo $conta_pagar->conta_pagar_obs; ?></textarea>
					   	  <?php echo form_error('conta_pagar_obs', '<small class="form-text text-danger">', '</small>'); ?>
					   </div>
				   </div>
				  
				</fieldset>
						
					<input type="hidden" name="conta_pagar_id" value="<?php echo $conta_pagar->conta_pagar_id; ?>"/>
					
					<?php 
						if($conta_pagar->conta_pagar_status == 1){
							echo '  <a href="'.base_url("pagar").'" class="btn btn-success btn-sm mt-4"><i class="fas fa-arrow-left"></i>&nbsp; Conta Paga - Voltar</a>';
						}else{
							echo '<button type="submit" class="btn btn-primary btn-sm mt-4">Salvar</button>';
						}					
					?>
					
				</form>
            </div>
          </div>

	</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->
