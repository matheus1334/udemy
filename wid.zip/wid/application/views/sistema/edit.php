
<?php $this->load->view('_includes/sidebar'); ?>
    
   
<!-- Main Content -->
<div id="content">

	<?php $this->load->view('_includes/topbar.php'); ?>


	<!-- Begin Page Content -->
	<div class="container-fluid">

	  <nav aria-label="breadcrumb">
		  <ol class="breadcrumb">
		    <li class="breadcrumb-item"><a href="<?php echo base_url('usuario'); ?>">Usuários</a></li>
		    <li class="breadcrumb-item active" aria-current="page"><?php echo $titulo; ?></li>
		  </ol>
		</nav>

		<!-- mensagem de sucesso -->
		<?php if($message = $this->session->flashdata('sucesso')){ ?>	
			<div class="row">
				<div class="col-md-12">
					<div class="alert alert-success alert-dismissible fade show" role="alert">
					  <strong><i class="far fa-smile-wink"></i>&nbsp;<?php echo $message; ?></strong>
					  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
					    <span aria-hidden="true">&times;</span>
					  </button>
					</div>
				</div>
			</div>
		<?php } ?>
		<!-- fim mensagem de sucesso -->
		
		
		<!-- mensagem de erro -->
		<?php if($message = $this->session->flashdata('error')){ ?>	
		<div class="row">
			<div class="col-md-12">
				<div class="alert alert-danger alert-dismissible fade show" role="alert">
				  <strong><i class="fas fa-exclamation-triangle"></i>&nbsp;<?php echo $message; ?></strong>
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
				    <span aria-hidden="true">&times;</span>
				  </button>
				</div>
			</div>
		</div>
		<?php } ?>
		<!--fim mensagem de erro-->
          
          
          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            
            <div class="card-body">
              <form method="post" name="form_edit">
				  <div class="form-group row">
				    <div class="col-md-3">
				    	<labe>Razão Social</labe>
				    	<input type="text" class="form-control" name="sistema_razao_social" placeholder="Razão Social" value="<?php echo $sistema->sistema_razao_social; ?>">	
				    	<?php echo form_error('sistema_razao_social', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				    <div class="col-md-3">
				    	<labe>Nome Fantasia</labe>
				    	<input type="text" class="form-control" name="sistema_nome_fantasia" placeholder="Nome Fantasia" value="<?php echo $sistema->sistema_nome_fantasia; ?>">
				    	<?php echo form_error('sistema_nome_fantasia', '<small class="form-text text-danger">', '</small>'); ?>	
				    </div>
				    <div class="col-md-3">
				    	<labe>CNPJ</labe>
				    	<input type="text" class="form-control cnpj" name="sistema_cnpj" placeholder="CNPJ" value="<?php echo $sistema->sistema_cnpj; ?>">	
				    	<?php echo form_error('sistema_cnpj', '<small class="form-text text-danger">', '</small>'); ?>
				    </div> 
				    <div class="col-md-3">
				    	<labe>Inscrição Estadual</labe>
				    	<input type="text" class="form-control" name="sistema_ie" placeholder="Inscrição Estadual" value="<?php echo $sistema->sistema_ie; ?>">	
				    	<?php echo form_error('sistema_ie', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				  </div><!-- fim linha -->
				  
				  
				  <div class="form-group row mt-4">
				    <div class="col-md-3">
				    	<labe>Telefone Fixo</labe>
				    	<input type="text" class="form-control sp_celphones" name="sistema_telefone_fixo" placeholder="Telefone Fixo" value="<?php echo $sistema->sistema_telefone_fixo; ?>">	
				    	<?php echo form_error('sistema_telefone_fixo', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				    <div class="col-md-3">
				    	<labe>Telefone Móvel</labe>
				    	<input type="text" class="form-control sp_celphones" name="sistema_telefone_movel" placeholder="Telefone Móvel" value="<?php echo $sistema->sistema_telefone_movel; ?>">
				    	<?php echo form_error('sistema_telefone_movel', '<small class="form-text text-danger">', '</small>'); ?>	
				    </div>
				    <div class="col-md-3">
				    	<labe>Email</labe>
				    	<input type="text" class="form-control" name="sistema_email" placeholder="E-mail" value="<?php echo $sistema->sistema_email; ?>">	
				    	<?php echo form_error('sistema_email', '<small class="form-text text-danger">', '</small>'); ?>
				    </div> 
				    <div class="col-md-3">
				    	<labe>Site URL</labe>
				    	<input type="text" class="form-control" name="sistema_site_url" placeholder="Site URL" value="<?php echo $sistema->sistema_site_url; ?>">	
				    	<?php echo form_error('sistema_site_url', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				  </div><!-- fim linha -->
				  
				  <div class="form-group row mt-4">
				    <div class="col-md-3">
				    	<labe>CEP</labe>
				    	<input type="text" class="form-control cep" name="sistema_cep" placeholder="CEP" value="<?php echo $sistema->sistema_cep; ?>">	
				    	<?php echo form_error('sistema_cep', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				    <div class="col-md-3">
				    	<labe>Endereço</labe>
				    	<input type="text" class="form-control" name="sistema_endereco" placeholder="Endereço" value="<?php echo $sistema->sistema_endereco; ?>">
				    	<?php echo form_error('sistema_endereco', '<small class="form-text text-danger">', '</small>'); ?>	
				    </div>
				    <div class="col-md-1">
				    	<labe>Nº</labe>
				    	<input type="text" class="form-control" name="sistema_numero" placeholder="Nº" value="<?php echo $sistema->sistema_numero; ?>">	
				    	<?php echo form_error('sistema_numero', '<small class="form-text text-danger">', '</small>'); ?>
				    </div> 
				    <div class="col-md-2">
				    	<labe>Bairro</labe>
				    	<input type="text" class="form-control" name="sistema_bairro" placeholder="Bairro" value="<?php echo $sistema->sistema_bairro; ?>">	
				    	<?php echo form_error('sistema_bairro', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				     <div class="col-md-2">
				    	<labe>Cidade</labe>
				    	<input type="text" class="form-control" name="sistema_cidade" placeholder="Cidade" value="<?php echo $sistema->sistema_cidade; ?>">	
				    	<?php echo form_error('sistema_cidade', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				     <div class="col-md-1">
				    	<labe>UF</labe>
				    	<input type="text" class="form-control uf" name="sistema_estado" placeholder="UF" value="<?php echo $sistema->sistema_estado; ?>">	
				    	<?php echo form_error('sistema_estado', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				  </div><!-- fim linha -->
				  
				  <div class="form-group row mt-4">
				     <div class="col-md-12">
				    	<labe>Ordem de serviço</labe>
				    	<textarea class="form-control" name="sistema_txt_ordem_servico" placeholder="Ordem de serviço"><?php echo $sistema->sistema_txt_ordem_servico; ?></textarea>	
				    	<?php echo form_error('sistema_txt_ordem_servico', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				  </div><!-- fim linha -->
				  
					<button type="submit" class="btn btn-primary btn-sm">Salvar</button>
				</form>
            </div>
          </div>

	</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->
