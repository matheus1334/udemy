 <style>
 	html, #wrapper{
 		background-color: #4e73df !important; 
 	}
 </style>
 
  <div class="container">

    <!-- Outer Row -->
    <div class="row justify-content-center">

      <div class="col-xl-10 col-lg-12 col-md-9">

        <div class="card o-hidden border-0 shadow-lg my-5" style="margin-top: 7em !important;">
          <div class="card-body p-0">
            <!-- Nested Row within Card Body -->	
            <div class="row">
              <div class="col-lg-6 d-none d-lg-block bg-login-image"></div>
              <div class="col-lg-6">
                <div class="p-5">
                  <div class="text-center">
                    <h1 class="h4 text-gray-900 mb-4">Seja Bem Vindo!</h1>
                  </div>
                  <form action="<?php echo base_url('login/auth'); ?>" class="user" method="post" name="form_auth">
                    <div class="form-group">
                      <input type="email" name="email" class="form-control form-control-user" placeholder="Entre com seu email...">
                    </div>
                    <div class="form-group">
                      <input type="password" name="password" class="form-control form-control-user"  placeholder="Password">
                    </div>
                    
                    <!-- mensagem de erro -->
					<?php if($message = $this->session->flashdata('info')){ ?>	
					<div class="row">
						<div class="col-md-12">
							<div class="alert alert-danger alert-dismissible fade show" role="alert">
							  <strong><i class="fas fa-exclamation-triangle"></i>&nbsp;<?php echo $message; ?></strong>
							  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
							    <span aria-hidden="true">&times;</span>
							  </button>
							</div>
						</div>
					</div>
					<?php } ?>
					<!--fim mensagem de erro-->
                    
                    <!-- mensagem de erro -->
					<?php if($message = $this->session->flashdata('error')){ ?>	
					<div class="row">
						<div class="col-md-12">
							<div class="alert alert-danger alert-dismissible fade show" role="alert">
							  <strong><i class="fas fa-exclamation-triangle"></i>&nbsp;<?php echo $message; ?></strong>
							  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
							    <span aria-hidden="true">&times;</span>
							  </button>
							</div>
						</div>
					</div>
					<?php } ?>
					<!--fim mensagem de erro-->
                    
                    <button type="submit" class="btn btn-primary btn-user btn-block">Entrar</button>
                    <hr>
                    
                  </form>
                  <div class="text-center">
                    <a class="small" href="forgot-password.html">Esqueceu a Senha?</a>
                  </div>
                  <div class="text-center">
                    <a class="small" href="register.html">Solicite uma conta!</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>

    </div>

  </div>
  
  <!-- Bootstrap core JavaScript-->
  <script src="<?php echo base_url('assets/vendor/jquery/jquery.min.js');?>"></script>
  <script src="<?php echo base_url('assets/vendor/bootstrap/js/bootstrap.bundle.min.js');?>"></script>

  <!-- Core plugin JavaScript-->
  <script src="<?php echo base_url('assets/vendor/jquery-easing/jquery.easing.min.js'); ?>"></script>

  <!-- Custom scripts for all pages-->
  <script src="<?php echo base_url('assets/js/sb-admin-2.min.js'); ?>"></script>

	<?php if(isset($scripts)){ ?>
	
	  <?php foreach($scripts as $script){?>
	  	<script src="<?php echo base_url('assets/'.$script)?>" rel="stylesheet"></script>
	  <?php } ?>
	 
	<?php } ?>


</body>

</html>


