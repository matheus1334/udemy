
<?php $this->load->view('_includes/sidebar'); ?>
    
   
<!-- Main Content -->
<div id="content">

	<?php $this->load->view('_includes/topbar.php'); ?>


	<!-- Begin Page Content -->
	<div class="container-fluid">

	  <nav aria-label="breadcrumb">
		  <ol class="breadcrumb">
		    <li class="breadcrumb-item"><a href="<?php echo base_url('usuario'); ?>">Usuários</a></li>
		    <li class="breadcrumb-item active" aria-current="page"><?php echo $titulo; ?></li>
		  </ol>
		</nav>

          <!-- DataTales Example -->
          <div class="card shadow mb-4">
          <?php if($this->ion_auth->is_admin()){?>
			<div class="card-header py-3">
              <a href="<?php echo base_url('usuario'); ?>" class="btn btn-success btn-sm float-right"><i class="fas fa-arrow-left"></i>&nbsp; Voltar</a>
            </div>
            <?php } else{ ?>
            <div class="card-header py-3">
              <a href="<?php echo base_url(); ?>" class="btn btn-success btn-sm float-right"><i class="fas fa-arrow-left"></i>&nbsp; Voltar</a>
            </div>
            <?php } ?>
            
            <div class="card-body">
              <form method="post" name="form_edit">
				  <div class="form-group row">
				    <div class="col-md-4">
				    	<labe>Nome</labe>
				    	<input type="text" class="form-control" name="first_name" placeholder="Seu Nome" value="<?php echo $usuario->first_name; ?>">	
				    	<?php echo form_error('first_name', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				    <div class="col-md-4">
				    	<labe>Sobrenome</labe>
				    	<input type="text" class="form-control" name="last_name" placeholder="Seu Sobrenome" value="<?php echo $usuario->last_name; ?>">
				    	<?php echo form_error('last_name', '<small class="form-text text-danger">', '</small>'); ?>	
				    </div>
				    <div class="col-md-4">
				    	<labe>Email (login)</labe>
				    	<input type="text" class="form-control" name="email" placeholder="Seu email" value="<?php echo $usuario->email; ?>">	
				    	<?php echo form_error('email', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				  </div><!-- fim linha -->
				  
				  <div class="form-group row">
					  <div class="col-md-4">
					    	<labe>Usuário</labe>
					    	<input type="text" class="form-control" name="username" placeholder="Seu Usuário" value="<?php echo $usuario->username; ?>">	
					    	<?php echo form_error('username', '<small class="form-text text-danger">', '</small>'); ?>	
					    </div>
				  	<div class="col-md-4">
				    	<labe>Ativo</labe>
				    	<select class="form-control" name="active" <?php echo (!$this->ion_auth->is_admin() ? 'disabled' : ''); ?> >
							<option value="0" <?php echo ($usuario->active == 0) ? 'selected' : ''; ?>>Não</option>
							<option value="1" <?php echo ($usuario->active == 1) ? 'selected' : ''; ?>>Sim</option>
				    	</select>
				    </div>
				    <div class="col-md-4">
				    	<labe>Perfil de Acesso</labe>
				    	<select class="form-control" name="perfil_usuario"  <?php echo (!$this->ion_auth->is_admin() ? 'disabled' : ''); ?>>
							<option value="2" <?php echo ($perfil_usuario->id == 2) ? 'selected' : ''; ?>>Vendedor</option>
							<option value="1" <?php echo ($perfil_usuario->id == 1) ? 'selected' : ''; ?>>Administrador</option>
				    	</select>
				    </div>
				  </div><!-- linha -->
					<div class="form-group row">
						<div class="col-md-6">
							<labe>Senha</labe>
							<input type="password" class="form-control" name="password" placeholder="Sua senha"/>
							<?php echo form_error('password', '<small class="form-text text-danger">', '</small>'); ?>
						</div>
						<div class="col-md-6">
							<labe>Confirme Senha</labe>
							<input type="password" class="form-control" name="confirm_password" placeholder="Confirme sua senha"/>
							<?php echo form_error('confirm_password', '<small class="form-text text-danger">', '</small>'); ?>
						</div>
					</div>
					<input type="hidden" name="usuario_id" value="<?php echo $usuario->id; ?>"/>
					<button type="submit" class="btn btn-primary btn-sm">Salvar</button>
				</form>
            </div>
          </div>

	</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->
