<style>
.font-small{
	font-size: 1em;
}
</style>


<?php $this->load->view('_includes/sidebar'); ?>
    
   
<!-- Main Content -->
<div id="content">

	<?php $this->load->view('_includes/topbar.php'); ?>


	<!-- Begin Page Content -->
	<div class="container-fluid">

	  <nav aria-label="breadcrumb">
		  <ol class="breadcrumb">
		    <li class="breadcrumb-item"><a href="<?php echo base_url('receber'); ?>">Contas a Receber</a></li>
		    <li class="breadcrumb-item active" aria-current="page"><?php echo $titulo; ?></li>
		  </ol>
		</nav>

          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <a href="<?php echo base_url('receber'); ?>" class="btn btn-success btn-sm float-right"><i class="fas fa-arrow-left"></i>&nbsp; Voltar</a>
            </div>
            <div class="card-body">
              <form method="post" name="form_edit">
              <div class="form-group row">
				    <div class="col-md-8">
              	<p><strong><i class="fas fa-clock"></i>&nbsp;&nbsp;Última alteração em: <?php echo formata_data_banco_com_hora($conta_receber->conta_receber_data_alteracao); ?></strong></p>
              		</div>
              		
              	</div>
              	
              	
              	<fieldset class="mt-4 border p-3">
              		<legend class="font-small">Dados da Conta</legend>
              	
				
				   <div class="form-group row">
		  
				    <div class="col-md-4">
				    	<labe>Cliente</labe>
				    	<select class="custom-select contas_receber" name="conta_receber_cliente_id">
							 <?php 
							 
							 	foreach($clientes as $cliente){
							 		
							 		echo '
							 		<option value="'.$cliente->cliente_id.'" '.($cliente->cliente_id == $conta_receber->conta_receber_cliente_id ? 'selected' : $cliente->cliente_nome).' '.($cliente->cliente_ativo == 2 ? 'disabled' : '').' >'
							 		.($cliente->cliente_ativo == 2 ? $cliente->cliente_nome.'&nbsp; -> CLIENTE INATIVO' : $cliente->cliente_nome).'
							 		</option>';
							 	}
							 
							 ?>				    		
				    	</select>
				    	<?php echo form_error('conta_receber_cliente_id', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				    <div class="col-md-3">
				    	<labe>Data Vencimento</labe>
				    	<input type="date" class="form-control" name="conta_receber_data_vencto" placeholder="Data" value="<?php echo $conta_receber->conta_receber_data_vencto; ?>">	
				    		<?php echo form_error('conta_receber_data_vencto', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				    
				    <div class="col-md-3">
				    	<labe>Valor</labe>
				    	<input type="text" class="form-control money2" name="conta_receber_valor" placeholder="Valor" value="<?php echo $conta_receber->conta_receber_valor; ?>">	
				    		<?php echo form_error('conta_receber_valor', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				    
				    <div class="col-md-2">
				    	<labe>Situação</labe>
				    	<select class="custom-select" name="conta_receber_status">
							 <?php 
							 
							 echo '<option value="0" '.($conta_receber->conta_receber_status == 0 ? 'selected' : '').'>Pendente</option>';
							 echo '<option value="1" '.($conta_receber->conta_receber_status == 1 ? 'selected' : '').'>Paga</option>';

							 ?>				    		
				    	</select>
				    	<?php echo form_error('conta_receber_cliente_id', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				  </div><!-- fim linha -->
				  
				   <div class="form-group row">
				   	  <div class="col-md-12">
					   	  <labe>Observação</labe>
					   	  <textarea name="conta_receber_obs" class="form-control" placeholder="Observação"><?php echo $conta_receber->conta_receber_obs; ?></textarea>
					   	  <?php echo form_error('conta_receber_obs', '<small class="form-text text-danger">', '</small>'); ?>
					   </div>
				   </div>
				  
				</fieldset>
						
					<input type="hidden" name="conta_receber_id" value="<?php echo $conta_receber->conta_receber_id; ?>"/>
					
					<?php 
						if($conta_receber->conta_receber_status == 1){
							echo '  <a href="'.base_url("receber").'" class="btn btn-success btn-sm mt-4"><i class="fas fa-arrow-left"></i>&nbsp; Conta Paga - Voltar</a>';
						}else{
							echo '<button type="submit" class="btn btn-primary btn-sm mt-4">Salvar</button>';
						}					
					?>
					
				</form>
            </div>
          </div>

	</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->
