<style>
.font-small{
	font-size: 1em;
}
</style>


<?php $this->load->view('_includes/sidebar'); ?>
    
   
<!-- Main Content -->
<div id="content">

	<?php $this->load->view('_includes/topbar.php'); ?>


	<!-- Begin Page Content -->
	<div class="container-fluid">

	  <nav aria-label="breadcrumb">
		  <ol class="breadcrumb">
		    <li class="breadcrumb-item"><a href="<?php echo base_url('cliente'); ?>">Clientes</a></li>
		    <li class="breadcrumb-item active" aria-current="page"><?php echo $titulo; ?></li>
		  </ol>
		</nav>

          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <a href="<?php echo base_url('cliente'); ?>" class="btn btn-success btn-sm float-right"><i class="fas fa-arrow-left"></i>&nbsp; Voltar</a>
            </div>
            <div class="card-body">
              <form method="post" name="form_add">
              
             	 <div class="custom-control custom-radio custom-control-inline mt-2">
                    <input type="radio" id="pessoa_fisica" name="cliente_tipo" class="custom-control-input" value="1" <?php echo set_checkbox('cliente_tipo', '1') ?> checked="">
                    <label class="custom-control-label pb-1" for="pessoa_fisica">Pessoa física</label>
                </div>
                <div class="custom-control custom-radio custom-control-inline">
                    <input type="radio" id="pessoa_juridica" name="cliente_tipo" class="custom-control-input" value="2" <?php echo set_checkbox('cliente_tipo', '2') ?> >
                    <label class="custom-control-label pb-1" for="pessoa_juridica">Pessoa jurídica</label>
                </div>
              
              	<fieldset class="mt-4 border p-3">
              		<legend class="font-small">Informações pessoais</legend>
              	
				  <div class="form-group row">
				    <div class="col-md-4">
				    	<labe>Nome</labe>
				    	<input type="text" class="form-control" name="cliente_nome" placeholder="Nome" value="<?php echo set_value('cliente_nome'); ?>">	
				    	<?php echo form_error('cliente_nome', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				    <div class="col-md-4">
				    	<labe>Sobrenome</labe>
				    	<input type="text" class="form-control" name="cliente_sobrenome" placeholder="Sobrenome" value="<?php echo set_value('cliente_sobrenome'); ?>">
				    	<?php echo form_error('cliente_sobrenome', '<small class="form-text text-danger">', '</small>'); ?>	
				    </div>
				    <div class="col-md-4">
				    	<labe>Data Nascimento</labe>
				    	<input type="date" class="form-control" name="cliente_data_nascimento" placeholder="Data Nascimento" value="<?php echo set_value('cliente_data_nascimento'); ?>">	
				    	<?php echo form_error('cliente_data_nascimento', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				  </div><!-- fim linha -->
				  
				  <div class="form-group row">
					 
				  	<div class="col-md-4">
				  		
				  		<div class="pessoa_fisica">
				  			<labe>CPF</labe>
					    	<input type="text" class="form-control cpf" name="cliente_cpf" placeholder="CPF" value="<?php echo set_value('cliente_cpf');?>">	
					    	<?php echo form_error('cliente_cpf', '<small class="form-text text-danger">', '</small>'); ?>
				  		</div>
						<div class="pessoa_juridica">
				  			<labe>CNPJ</labe>
					    	<input type="text" class="form-control cnpj" name="cliente_cnpj" placeholder="CNPJ" value="<?php echo set_value('cliente_cnpj');?>">	
					    	<?php echo form_error('cliente_cnpj', '<small class="form-text text-danger">', '</small>'); ?>
				  		</div>
					    	
					    
					    	
				    </div>
				    <div class="col-md-4">
				    
				    	
						<labe class="pessoa_fisica">RG</labe>
						<labe class="pessoa_juridica">IE</labe>
					    <input type="text" class="form-control" name="cliente_rg_ie" placeholder="RG/IE" value="<?php echo set_value('cliente_rg_ie'); ?>">	
				    	<?php echo form_error('cliente_rg_ie', '<small class="form-text text-danger">', '</small>'); ?>
				    	
				    </div>
				  </div><!-- linha -->
				</fieldset>
				
              	<fieldset class="mt-4 border p-3">
              		<legend class="font-small">Contato</legend>
              	
				  	<div class="form-group row">
					  <div class="col-md-4">
					    	<labe>E-mail</labe>
					    	<input type="text" class="form-control" name="cliente_email" placeholder="Email" value="<?php echo set_value('cliente_email'); ?>">	
				    		<?php echo form_error('cliente_email', '<small class="form-text text-danger">', '</small>'); ?>
					    </div>
				  	<div class="col-md-4">
				    	<labe>Telefone</labe>
				    	<input type="text" class="form-control sp_celphones" name="cliente_telefone" placeholder="Telefone" value="<?php echo set_value('cliente_telefone'); ?>">	
				    	<?php echo form_error('cliente_telefone', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				    <div class="col-md-4">
				    	<labe>Celular</labe>
				    	<input type="text" class="form-control sp_celphones" name="cliente_celular" placeholder="Celular" value="<?php echo set_value('cliente_celular'); ?>">	
				    	<?php echo form_error('cliente_celular', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				  </div><!-- linha -->
					
					
				<div class="form-group row mt-4">
				    <div class="col-md-3">
				    	<labe>CEP</labe>
				    	<input type="text" class="form-control cep" name="cliente_cep" placeholder="CEP" value="<?php echo set_value('cliente_cep'); ?>">	
				    	<?php echo form_error('cliente_cep', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				    <div class="col-md-3">
				    	<labe>Endereço</labe>
				    	<input type="text" class="form-control" name="cliente_endereco" placeholder="Endereço" value="<?php echo set_value('cliente_endereco'); ?>">
				    	<?php echo form_error('cliente_endereco', '<small class="form-text text-danger">', '</small>'); ?>	
				    </div>
				    <div class="col-md-1">
				    	<labe>Nº</labe>
				    	<input type="text" class="form-control" name="cliente_numero_endereco" placeholder="Nº" value="<?php echo set_value('cliente_numero_endereco'); ?>">	
				    	<?php echo form_error('cliente_numero_endereco', '<small class="form-text text-danger">', '</small>'); ?>
				    </div> 
				    <div class="col-md-2">
				    	<labe>Bairro</labe>
				    	<input type="text" class="form-control" name="cliente_bairro" placeholder="Bairro" value="<?php echo set_value('cliente_bairro'); ?>">	
				    	<?php echo form_error('cliente_bairro', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				     <div class="col-md-2">
				    	<labe>Cidade</labe>
				    	<input type="text" class="form-control" name="cliente_cidade" placeholder="Cidade" value="<?php echo set_value('cliente_cidade'); ?>">	
				    	<?php echo form_error('cliente_cidade', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				     <div class="col-md-1">
				    	<labe>UF</labe>
				    	<input type="text" class="form-control uf" name="cliente_estado" placeholder="UF" value="<?php echo set_value('cliente_estado'); ?>">	
				    	<?php echo form_error('cliente_estado', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				  </div><!-- fim linha -->	
				</fieldset>
				
              	<fieldset class="mt-4 border p-3">
              		<legend class="font-small">Observações</legend>
              	
				   <div class="form-group row">
				     <div class="col-md-12">
				    	<labe>Observacao</labe>
				    	<textarea class="form-control" name="cliente_obs" placeholder="Ordem de serviço"></textarea>	
				    	<?php echo form_error('cliente_obs', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				  </div><!-- fim linha -->
				</fieldset>
					<button type="submit" class="btn btn-primary btn-sm mt-4">Salvar</button>
				</form>
            </div>
          </div>

	</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->
