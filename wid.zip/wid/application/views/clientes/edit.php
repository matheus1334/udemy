<style>
.font-small{
	font-size: 1em;
}
</style>


<?php $this->load->view('_includes/sidebar'); ?>
    
   
<!-- Main Content -->
<div id="content">

	<?php $this->load->view('_includes/topbar.php'); ?>


	<!-- Begin Page Content -->
	<div class="container-fluid">

	  <nav aria-label="breadcrumb">
		  <ol class="breadcrumb">
		    <li class="breadcrumb-item"><a href="<?php echo base_url('cliente'); ?>">Clientes</a></li>
		    <li class="breadcrumb-item active" aria-current="page"><?php echo $titulo; ?></li>
		  </ol>
		</nav>

          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <a href="<?php echo base_url('cliente'); ?>" class="btn btn-success btn-sm float-right"><i class="fas fa-arrow-left"></i>&nbsp; Voltar</a>
            </div>
            <div class="card-body">
              <form method="post" name="form_edit">
              <div class="form-group row">
				    <div class="col-md-8">
              	<p><strong><i class="fas fa-clock"></i>&nbsp;&nbsp;Última alteração em: <?php echo formata_data_banco_com_hora($clientes->cliente_data_alteracao); ?></strong></p>
              		</div>
              		
				    <div class="col-md-4">
				    	<select class="form-control" name="cliente_ativo">
				    		<option value="1" <?php echo ($clientes->cliente_ativo == 1) ? 'selected' : ''; ?>>Ativo</option>
							<option value="2" <?php echo ($clientes->cliente_ativo == 2) ? 'selected' : ''; ?>>Inativo</option>
				    	</select>
				    </div>
              	</div>
              	
              	
              	<fieldset class="mt-4 border p-3">
              		<legend class="font-small">Informações pessoais</legend>
              	
				  <div class="form-group row">
				    <div class="col-md-4">
				    	<labe>Nome</labe>
				    	<input type="text" class="form-control" name="cliente_nome" placeholder="Nome" value="<?php echo $clientes->cliente_nome; ?>">	
				    	<?php echo form_error('cliente_nome', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				    <div class="col-md-4">
				    	<labe>Sobrenome</labe>
				    	<input type="text" class="form-control" name="cliente_sobrenome" placeholder="Sobrenome" value="<?php echo $clientes->cliente_sobrenome; ?>">
				    	<?php echo form_error('cliente_sobrenome', '<small class="form-text text-danger">', '</small>'); ?>	
				    </div>
				    <div class="col-md-4">
				    	<labe>Data Nascimento</labe>
				    	<input type="date" class="form-control" name="cliente_data_nascimento" placeholder="Data Nascimento" value="<?php echo $clientes->cliente_data_nascimento; ?>">	
				    	<?php echo form_error('cliente_data_nascimento', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				  </div><!-- fim linha -->
				  
				  <div class="form-group row">
					  <div class="col-md-4">
					    	<labe>Tipo Pessoa</labe>
					    	<select class="form-control" name="cliente_tipo">
								<option value="1" <?php echo ($clientes->cliente_tipo == 1) ? 'selected' : ''; ?>>Pessoa Física</option>
								<option value="2" <?php echo ($clientes->cliente_tipo == 2) ? 'selected' : ''; ?>>Pessoa Juridíca</option>
							</select>
					    </div>
				  	<div class="col-md-4">
				  		
						<?php if($clientes->cliente_tipo == 1){ ?>
					    	<labe>CPF</labe>
					    	<input type="text" class="form-control cpf" name="cliente_cpf" placeholder="<?php echo ($clientes->cliente_tipo == 1 ? 'CPF' : 'CNPJ');?>" value="<?php echo $clientes->cliente_cpf_cnpj; ?>">	
					    	<?php echo form_error('cliente_cpf', '<small class="form-text text-danger">', '</small>'); ?>
					    <?php }else{?> 
					    	<labe>CNPJ</labe>
					    	<input type="text" class="form-control cnpj" name="cliente_cnpj" placeholder="<?php echo ($clientes->cliente_tipo == 1 ? 'CPF' : 'CNPJ');?>" value="<?php echo $clientes->cliente_cpf_cnpj; ?>">	
					    	<?php echo form_error('cliente_cnpj', '<small class="form-text text-danger">', '</small>'); ?>
					    <?php }?>
					    	
				    </div>
				    <div class="col-md-4">
				    	<?php if($clientes->cliente_tipo == 1){ ?>
					    	<labe>RG</labe>
					    <?php }else if($clientes->cliente_tipo == 2){?> 
					    	<labe>IE</labe>
					    <?php }else{ ?>
					    	<labe>RG / IE</labe>
					    <?php } ?>
				    	<input type="text" class="form-control" name="cliente_rg_ie" placeholder="<?php echo ($clientes->cliente_tipo == 1 ? 'RG' : 'IE');?>" value="<?php echo $clientes->cliente_rg_ie; ?>">	
				    	<?php echo form_error('cliente_rg_ie', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				  </div><!-- linha -->
				</fieldset>
				
              	<fieldset class="mt-4 border p-3">
              		<legend class="font-small">Contato</legend>
              	
				  	<div class="form-group row">
					  <div class="col-md-4">
					    	<labe>E-mail</labe>
					    	<input type="text" class="form-control" name="cliente_email" placeholder="Email" value="<?php echo $clientes->cliente_email; ?>">	
				    		<?php echo form_error('cliente_email', '<small class="form-text text-danger">', '</small>'); ?>
					    </div>
				  	<div class="col-md-4">
				    	<labe>Telefone</labe>
				    	<input type="text" class="form-control sp_celphones" name="cliente_telefone" placeholder="Telefone" value="<?php echo $clientes->cliente_telefone; ?>">	
				    	<?php echo form_error('cliente_telefone', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				    <div class="col-md-4">
				    	<labe>Celular</labe>
				    	<input type="text" class="form-control sp_celphones" name="cliente_celular" placeholder="Celular" value="<?php echo $clientes->cliente_celular; ?>">	
				    	<?php echo form_error('cliente_celular', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				  </div><!-- linha -->
					
					
				<div class="form-group row mt-4">
				    <div class="col-md-3">
				    	<labe>CEP</labe>
				    	<input type="text" class="form-control cep" name="cliente_cep" placeholder="CEP" value="<?php echo $clientes->cliente_cep; ?>">	
				    	<?php echo form_error('cliente_cep', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				    <div class="col-md-3">
				    	<labe>Endereço</labe>
				    	<input type="text" class="form-control" name="cliente_endereco" placeholder="Endereço" value="<?php echo $clientes->cliente_endereco; ?>">
				    	<?php echo form_error('cliente_endereco', '<small class="form-text text-danger">', '</small>'); ?>	
				    </div>
				    <div class="col-md-1">
				    	<labe>Nº</labe>
				    	<input type="text" class="form-control" name="cliente_numero_endereco" placeholder="Nº" value="<?php echo $clientes->cliente_numero_endereco; ?>">	
				    	<?php echo form_error('cliente_numero_endereco', '<small class="form-text text-danger">', '</small>'); ?>
				    </div> 
				    <div class="col-md-2">
				    	<labe>Bairro</labe>
				    	<input type="text" class="form-control" name="cliente_bairro" placeholder="Bairro" value="<?php echo $clientes->cliente_bairro; ?>">	
				    	<?php echo form_error('cliente_bairro', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				     <div class="col-md-2">
				    	<labe>Cidade</labe>
				    	<input type="text" class="form-control" name="cliente_cidade" placeholder="Cidade" value="<?php echo $clientes->cliente_cidade; ?>">	
				    	<?php echo form_error('cliente_cidade', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				     <div class="col-md-1">
				    	<labe>UF</labe>
				    	<input type="text" class="form-control uf" name="cliente_estado" placeholder="UF" value="<?php echo $clientes->cliente_estado; ?>">	
				    	<?php echo form_error('cliente_estado', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				  </div><!-- fim linha -->	
				</fieldset>
				
              	<fieldset class="mt-4 border p-3">
              		<legend class="font-small">Observações</legend>
              	
				   <div class="form-group row mt-4">
				     <div class="col-md-12">
				    	<labe>Observacao</labe>
				    	<textarea class="form-control" name="cliente_obs" placeholder="Ordem de serviço"><?php echo $clientes->cliente_obs; ?></textarea>	
				    	<?php echo form_error('cliente_obs', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				  </div><!-- fim linha -->
				</fieldset>
					<input type="hidden" name="cliente_id" value="<?php echo $clientes->cliente_id; ?>"/>
					<button type="submit" class="btn btn-primary btn-sm mt-4">Salvar</button>
				</form>
            </div>
          </div>

	</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->
