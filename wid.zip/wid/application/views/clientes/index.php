
<?php $this->load->view('_includes/sidebar'); ?>
    
   
<!-- Main Content -->
<div id="content">

	<?php $this->load->view('_includes/topbar.php'); ?>


	<!-- Begin Page Content -->
	<div class="container-fluid">

	  <nav aria-label="breadcrumb">
		  <ol class="breadcrumb">
		    <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>">Home</a></li>
		    <li class="breadcrumb-item active" aria-current="page"><?php echo $titulo; ?></li>
		  </ol>
		</nav>
		
		<!-- mensagem de sucesso -->
		<?php if($message = $this->session->flashdata('sucesso')){ ?>	
			<div class="row">
				<div class="col-md-12">
					<div class="alert alert-success alert-dismissible fade show" role="alert">
					  <strong><i class="far fa-smile-wink"></i>&nbsp;<?php echo $message; ?></strong>
					  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
					    <span aria-hidden="true">&times;</span>
					  </button>
					</div>
				</div>
			</div>
		<?php } ?>
		<!-- fim mensagem de sucesso -->
		
		
		<!-- mensagem de erro -->
		<?php if($message = $this->session->flashdata('error')){ ?>	
		<div class="row">
			<div class="col-md-12">
				<div class="alert alert-danger alert-dismissible fade show" role="alert">
				  <strong><i class="fas fa-exclamation-triangle"></i>&nbsp;<?php echo $message; ?></strong>
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
				    <span aria-hidden="true">&times;</span>
				  </button>
				</div>
			</div>
		</div>
		<?php } ?>
		<!--fim mensagem de erro-->
          
          
          
          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <a href="<?php echo base_url('cliente/add'); ?>" class="btn btn-success btn-sm float-right"><i class="fas fa-user-plus"></i>&nbsp; Novo</a>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th class="text-center">#</th>
                      <th>Nome</th>
                      <th>CPF / CNPJ</th>
                      <th>Tipo Cliente</th>
                      <th class="text-center">Ativo</th>
                      <th class="text-right no-sort">Ações</th>
                    </tr>
                  </thead>
                  <tbody>
                  <?php foreach($clientes as $cli) : ?>
                    <tr>
                      <td class="text-center pr-4"><?php echo $cli->cliente_id; ?></td>
                      <td><?php echo $cli->cliente_nome; ?></td>
                      <td><?php echo $cli->cliente_cpf_cnpj; ?></td>
                      <td><?php echo ($cli->cliente_tipo == 1 ? 'Pessoa Física' : 'Pessoa Jurídica'); ?></td>
                      <td class="text-center pr-4"><?php echo ($cli->cliente_ativo == 1 ? '<h5><span class="badge badge-info btn-lg">Ativo</span></h5>' : '<h5><span class="badge badge-warning">Inativo</span></h5>'); ?></td>
                      <td class="text-right">
                      	<a href="<?php echo base_url('cliente/edit/'.$cli->cliente_id); ?>" class="btn btn-sm btn-primary"><i class="fas fa-user-edit"></i></a>
                      	<a href="javascript(void)" data-toggle="modal" data-target="#cli-<?php echo $cli->cliente_id;?>" class="btn btn-sm btn-danger"><i class="fas fa-user-times"></i</a>
                      </td> 
                    </tr>
                    
                    
                    <!-- modal de confirmação para exclui usuario -->
                    <div class="modal fade" id="cli-<?php echo $cli->cliente_id;?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
					    <div class="modal-dialog" role="document">
					      <div class="modal-content">
					        <div class="modal-header">
					          <h5 class="modal-title" id="exampleModalLabel">Tem certeza que gostaria de deletar o cliente?</h5>
					          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
					            <span aria-hidden="true">×</span>
					          </button>
					        </div>
					        <div class="modal-body">Se você deseja realmente excluir o cliente clique em sim, ele será removido totalmende do banco de dados.</div>
					        <div class="modal-footer">
					          <button class="btn btn-secondary" type="button" data-dismiss="modal">Não</button>
					          <a class="btn btn-danger" href="<?php echo base_url('cliente/delete/'.$cli->cliente_id); ?>">Sim</a>
					        </div>
					      </div>
					    </div>
  					</div>
                    <!--- fim do modal --->
                    <?php endforeach; ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

	</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->
