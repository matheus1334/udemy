<style>
.font-small{
	font-size: 1em;
}
</style>


<?php $this->load->view('_includes/sidebar'); ?>
    
   
<!-- Main Content -->
<div id="content">

	<?php $this->load->view('_includes/topbar.php'); ?>


	<!-- Begin Page Content -->
	<div class="container-fluid">

	  <nav aria-label="breadcrumb">
		  <ol class="breadcrumb">
		    <li class="breadcrumb-item"><a href="<?php echo base_url('fornecedor'); ?>">Fornecedores</a></li>
		    <li class="breadcrumb-item active" aria-current="page"><?php echo $titulo; ?></li>
		  </ol>
		</nav>

          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <a href="<?php echo base_url('fornecedor'); ?>" class="btn btn-success btn-sm float-right"><i class="fas fa-arrow-left"></i>&nbsp; Voltar</a>
            </div>
            <div class="card-body">
              <form method="post" name="form_edit">
              	
              	<div class="form-group row">
				    <div class="col-md-8">
              			<p><strong><i class="fas fa-clock"></i>&nbsp;&nbsp;Última alteração em: <?php echo formata_data_banco_com_hora($fornecedores->fornecedor_data_alteracao); ?></strong></p>
              		</div>
              		
				    <div class="col-md-4">
				    	<select class="form-control" name="fornecedor_ativo">
				    		<option value="1" <?php echo ($fornecedores->fornecedor_ativo == 1) ? 'selected' : ''; ?>>Ativo</option>
							<option value="2" <?php echo ($fornecedores->fornecedor_ativo == 2) ? 'selected' : ''; ?>>Inativo</option>
				    	</select>
				    </div>
              	</div>
              	
              	<fieldset class="mt-4 border p-3">
              		<legend class="font-small">Informações</legend>
              	
				  <div class="form-group row">
				    <div class="col-md-6">
				    	<labe>Razão Social</labe>
				    	<input type="text" class="form-control" name="fornecedor_razao" placeholder="Razão Social" value="<?php echo $fornecedores->fornecedor_razao; ?>">	
				    	<?php echo form_error('fornecedor_razao', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				    <div class="col-md-6">
				    	<labe>Nome Fantasia</labe>
				    	<input type="text" class="form-control" name="fornecedor_nome_fantasia" placeholder="Nome Fantasia" value="<?php echo $fornecedores->fornecedor_nome_fantasia; ?>">
				    	<?php echo form_error('fornecedor_nome_fantasia', '<small class="form-text text-danger">', '</small>'); ?>	
				    </div>

				  </div><!-- fim linha -->
				  
				  <div class="form-group row">
				    <div class="col-md-6">
				    	<labe>CNPJ</labe>
				    	<input type="text" class="form-control cnpj" name="fornecedor_cnpj" placeholder="CNPJ" value="<?php echo $fornecedores->fornecedor_cnpj; ?>">	
				    	<?php echo form_error('fornecedor_cnpj', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				    <div class="col-md-6">
				    	<labe>IE</labe>
				    	<input type="text" class="form-control" name="fornecedor_ie" placeholder="IE" value="<?php echo $fornecedores->fornecedor_ie; ?>">
				    	<?php echo form_error('fornecedor_ie', '<small class="form-text text-danger">', '</small>'); ?>	
				    </div>

				  </div><!-- fim linha -->
				</fieldset>
				
              	<fieldset class="mt-4 border p-3">
              		<legend class="font-small">Contato</legend>
              	
				  	<div class="form-group row">
					  <div class="col-md-3">
					    	<labe>E-mail</labe>
					    	<input type="text" class="form-control" name="fornecedor_email" placeholder="Email" value="<?php echo $fornecedores->fornecedor_email; ?>">	
				    		<?php echo form_error('fornecedor_email', '<small class="form-text text-danger">', '</small>'); ?>
					    </div>
				  	<div class="col-md-3">
				    	<labe>Telefone</labe>
				    	<input type="text" class="form-control sp_celphones" name="fornecedor_telefone" placeholder="Telefone" value="<?php echo $fornecedores->fornecedor_telefone; ?>">	
				    	<?php echo form_error('fornecedor_telefone', '<small class="form-text text-danger">', '</small>'); ?>
				    </div> 
				    <div class="col-md-3">
				    	<labe>Celular</labe>
				    	<input type="text" class="form-control sp_celphones" name="fornecedor_celular" placeholder="Celular" value="<?php echo $fornecedores->fornecedor_celular; ?>">	
				    	<?php echo form_error('fornecedor_celular', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				    
				    <div class="col-md-3">
				    	<labe>Contato</labe>
				    	<input type="text" class="form-control" name="fornecedor_contato" placeholder="Contato" value="<?php echo $fornecedores->fornecedor_contato; ?>">	
				    	<?php echo form_error('fornecedor_contato', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				  </div><!-- linha -->
					
					
				<div class="form-group row mt-4">
				    <div class="col-md-3">
				    	<labe>CEP</labe>
				    	<input type="text" class="form-control cep" name="fornecedor_cep" placeholder="CEP" value="<?php echo $fornecedores->fornecedor_cep; ?>">	
				    	<?php echo form_error('fornecedor_cep', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				    <div class="col-md-3">
				    	<labe>Endereço</labe>
				    	<input type="text" class="form-control" name="fornecedor_endereco" placeholder="Endereço" value="<?php echo $fornecedores->fornecedor_endereco; ?>">
				    	<?php echo form_error('fornecedor_endereco', '<small class="form-text text-danger">', '</small>'); ?>	
				    </div>
				    <div class="col-md-1">
				    	<labe>Nº</labe>
				    	<input type="text" class="form-control" name="fornecedor_numero_endereco" placeholder="Nº" value="<?php echo $fornecedores->fornecedor_numero_endereco; ?>">	
				    	<?php echo form_error('fornecedor_numero_endereco', '<small class="form-text text-danger">', '</small>'); ?>
				    </div> 
				    <div class="col-md-2">
				    	<labe>Bairro</labe>
				    	<input type="text" class="form-control" name="fornecedor_bairro" placeholder="Bairro" value="<?php echo $fornecedores->fornecedor_bairro; ?>">	
				    	<?php echo form_error('fornecedor_bairro', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				     <div class="col-md-2">
				    	<labe>Cidade</labe>
				    	<input type="text" class="form-control" name="fornecedor_cidade" placeholder="Cidade" value="<?php echo $fornecedores->fornecedor_cidade; ?>">	
				    	<?php echo form_error('fornecedor_cidade', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				     <div class="col-md-1">
				    	<labe>UF</labe>
				    	<input type="text" class="form-control uf" name="fornecedor_estado" placeholder="UF" value="<?php echo $fornecedores->fornecedor_estado; ?>">	
				    	<?php echo form_error('fornecedor_estado', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				  </div><!-- fim linha -->	
				</fieldset>
				
              	<fieldset class="mt-4 border p-3">
              		<legend class="font-small">Observações</legend>
              	
				   <div class="form-group row">
				     <div class="col-md-12">
				    	<labe>Observacao</labe>
				    	<textarea class="form-control" name="fornecedor_obs" placeholder="Ordem de serviço"><?php echo $fornecedores->fornecedor_obs; ?></textarea>	
				    	<?php echo form_error('fornecedor_obs', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				  </div><!-- fim linha -->
				</fieldset>
					<input type="hidden" name="fornecedor_id" value="<?php echo $fornecedores->fornecedor_id; ?>"/>
					<button type="submit" class="btn btn-primary btn-sm mt-4">Salvar</button>
				</form>
            </div>
          </div>

	</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->
