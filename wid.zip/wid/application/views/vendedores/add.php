<style>
.font-small{
	font-size: 1em;
}
</style>


<?php $this->load->view('_includes/sidebar'); ?>
    
   
<!-- Main Content -->
<div id="content">

	<?php $this->load->view('_includes/topbar.php'); ?>


	<!-- Begin Page Content -->
	<div class="container-fluid">

	  <nav aria-label="breadcrumb">
		  <ol class="breadcrumb">
		    <li class="breadcrumb-item"><a href="<?php echo base_url('vendedor'); ?>">Vendedores</a></li>
		    <li class="breadcrumb-item active" aria-current="page"><?php echo $titulo; ?></li>
		  </ol>
		</nav>

          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <a href="<?php echo base_url('vendedor'); ?>" class="btn btn-success btn-sm float-right"><i class="fas fa-arrow-left"></i>&nbsp; Voltar</a>
            </div>
            <div class="card-body">
              <form method="post" name="form_edit">
              <div class="form-group row">
				    
              		
				    <div class="col-md-4">
				    	<select class="form-control" name="vendedor_ativo">
				    		<option value="1">Ativo</option>
							<option value="2">Inativo</option>
				    	</select>
				    </div>
              	</div>
              	
              	
              	<fieldset class="mt-4 border p-3">
              		<legend class="font-small">Informações pessoais</legend>
              	
				  <div class="form-group row">
				    <div class="col-md-3">
				    	<labe>Código</labe>
				    	<input type="text" class="form-control" name="vendedor_codigo" placeholder="Código" value="<?php echo $vendedor_codigo; ?>" readonly="">	
				    	<?php echo form_error('vendedor_codigo', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				    <div class="col-md-3">
				    	<labe>Nome</labe>
				    	<input type="text" class="form-control" name="vendedor_nome_completo" placeholder="Nome Completo" value="<?php echo set_value('vendedor_nome_completo'); ?>">	
				    	<?php echo form_error('vendedor_nome_completo', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				    <div class="col-md-3">
				    	<labe>CPF</labe>
				    	<input type="text" class="form-control cpf" name="vendedor_cpf" placeholder="CPF" value="<?php echo set_value('vendedor_cpf'); ?>">	
				    	<?php echo form_error('vendedor_cpf', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				    <div class="col-md-3">
				    	<labe>RG</labe>
				    	<input type="text" class="form-control" name="vendedor_rg" placeholder="RG" value="<?php echo set_value('vendedor_rg'); ?>">	
				    	<?php echo form_error('vendedor_rg', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				  </div><!-- fim linha -->
				  
				</fieldset>
				
              	<fieldset class="mt-4 border p-3">
              		<legend class="font-small">Contato</legend>
              	
				  	<div class="form-group row">
					  <div class="col-md-4">
					    	<labe>E-mail</labe>
					    	<input type="text" class="form-control" name="vendedor_email" placeholder="Email" value="<?php echo set_value('vendedor_email'); ?>">	
				    		<?php echo form_error('vendedor_email', '<small class="form-text text-danger">', '</small>'); ?>
					    </div>
				  	<div class="col-md-4">
				    	<labe>Telefone</labe>
				    	<input type="text" class="form-control sp_celphones" name="vendedor_telefone" placeholder="Telefone" value="<?php echo set_value('vendedor_telefone'); ?>">	
				    	<?php echo form_error('vendedor_telefone', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				    <div class="col-md-4">
				    	<labe>Celular</labe>
				    	<input type="text" class="form-control sp_celphones" name="vendedor_celular" placeholder="Celular" value="<?php echo set_value('vendedor_celular'); ?>">	
				    	<?php echo form_error('vendedor_celular', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				  </div><!-- linha -->
					
					
				<div class="form-group row mt-4">
				    <div class="col-md-3">
				    	<labe>CEP</labe>
				    	<input type="text" class="form-control cep" name="vendedor_cep" placeholder="CEP" value="<?php echo set_value('vendedor_cep'); ?>">	
				    	<?php echo form_error('vendedor_cep', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				    <div class="col-md-3">
				    	<labe>Endereço</labe>
				    	<input type="text" class="form-control" name="vendedor_endereco" placeholder="Endereço" value="<?php echo set_value('vendedor_endereco'); ?>">
				    	<?php echo form_error('vendedor_endereco', '<small class="form-text text-danger">', '</small>'); ?>	
				    </div>
				    <div class="col-md-1">
				    	<labe>Nº</labe>
				    	<input type="text" class="form-control" name="vendedor_numero_endereco" placeholder="Nº" value="<?php echo set_value('vendedor_numero_endereco'); ?>">	
				    	<?php echo form_error('vendedor_numero_endereco', '<small class="form-text text-danger">', '</small>'); ?>
				    </div> 
				    <div class="col-md-2">
				    	<labe>Bairro</labe>
				    	<input type="text" class="form-control" name="vendedor_bairro" placeholder="Bairro" value="<?php echo set_value('vendedor_bairro'); ?>">	
				    	<?php echo form_error('vendedor_bairro', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				     <div class="col-md-2">
				    	<labe>Cidade</labe>
				    	<input type="text" class="form-control" name="vendedor_cidade" placeholder="Cidade" value="<?php echo set_value('vendedor_cidade'); ?>">	
				    	<?php echo form_error('vendedor_cidade', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				     <div class="col-md-1">
				    	<labe>UF</labe>
				    	<input type="text" class="form-control uf" name="vendedor_estado" placeholder="UF" 
				    	value="<?php echo set_value('vendedor_estado'); ?>">	
				    	<?php echo form_error('vendedor_estado', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				  </div><!-- fim linha -->	
				</fieldset>
				
              	<fieldset class="mt-4 border p-3">
              		<legend class="font-small">Observações</legend>
              	
				   <div class="form-group row mt-4">
				     <div class="col-md-12">
				    	<labe>Observacao</labe>
				    	<textarea class="form-control" name="vendedor_obs" placeholder="Observação"></textarea>	
				    	<?php echo form_error('vendedor_obs', '<small class="form-text text-danger">', '</small>'); ?>
				    </div>
				  </div><!-- fim linha -->
				</fieldset>
					<button type="submit" class="btn btn-primary btn-sm mt-4">Salvar</button>
				</form>
            </div>
          </div>

	</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->
