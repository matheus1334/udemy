<?php 

defined('BASEPATH') OR exit ('Ação não permitida.');

Class Vendas extends CI_Controller{
	
	public function __construct(){
		parent::__construct();
	
		//definir se há sessão
		if(!$this->ion_auth->logged_in()){
			$this->session->set_flashdata('info', 'Sua sessão expirou.');
			redirect('login');
		}
		
		$this->load->model('Vendas_model');
		$this->load->model('Produtos_model');
		
	}
	public function index(){
		$data = array(
			'titulo' => 'Vendas de Produtos',
			'styles' => array(
				'vendor/datatables/dataTables.bootstrap4.min.css',
			),
			'scripts' => array(
				'vendor/datatables/jquery.dataTables.min.js',
				'vendor/datatables/dataTables.bootstrap4.min.js',
				'vendor/datatables/app.js',
			),
			'vendas' => $this->Vendas_model->get_all(),
		);
		
			$this->load->view('_includes/header', $data);
			$this->load->view('vendas/index');
			$this->load->view('_includes/footer');
	}
	

	public function add(){
	


		$this->form_validation->set_rules('venda_cliente_id', '','required');
		$this->form_validation->set_rules('venda_tipo', '','required');

		$this->form_validation->set_rules('venda_valor_total', '','required');
		$this->form_validation->set_rules('venda_vendedor_id', '','required');

 

		if($this->form_validation->run()){
			$venda_valor_total = str_replace('R$', '', trim($this->input->post('venda_valor_total')));
			
			$data = elements(
				array(
					'venda_cliente_id',
					'venda_forma_pagamento_id',
					'venda_tipo',
					'venda_vendedor_id',
					'venda_valor_desconto',
					'venda_valor_total',
				),$this->input->post()
			);
			
			$data['venda_valor_total'] = trim(preg_replace('/\$/', '', $venda_valor_total));
			$data = html_escape($data);
			
			$this->Core_model->insert('vendas', $data, TRUE);
			$id_venda = $this->session->userdata('last_id');
			
			// deletando de ordem_tem_servico, os serviços antigos da ordem editada
			 
			$this->Vendas_model->delete_old_products($venda_id);
			$produto_id = $this->input->post('produto_id');
			$produto_quantidade = $this->input->post('produto_quantidade');
			$produto_desconto = str_replace('%', '', $this->input->post('produto_desconto'));
			
			$produto_preco_venda = str_replace('R$', '',  $this->input->post('produto_preco_venda'));
			$produto_item_total = str_replace('R$', '',  $this->input->post('produto_item_total'));
			$produto_preco_venda = str_replace(',', '', $produto_preco_venda);
			$produto_item_total = str_replace(',', '',  $produto_item_total);
			
						 
			$qty_produto = count($produto_id);
			
			$venda_id = $this->input->post('venda_id');

			for($i = 0; $i < $qty_produto; $i++){
				
				$data = array(
					'venda_produto_id_venda' => $id_venda,
					'venda_produto_id_produto' => $produto_id[$i],
					'venda_produto_quantidade' => $produto_quantidade[$i],
					'venda_produto_valor_unitario' => $produto_preco_venda[$i],
					'venda_produto_desconto' => $produto_desconto[$i],
					'venda_produto_valor_total' => $produto_item_total[$i],
				);
				
				$data = html_escape($data);
				$this->Core_model->insert('venda_produtos', $data);
				
				
				//atualiza estoque
				$produto_qtde_estoque = 0;
				// transforma em inteiro o valor que vem do array
				$produto_qtde_estoque += intval($produto_quantidade[$i]);
				
				
				$produtos = array(
					'produto_qtde_estoque' => $produto_qtde_estoque,
				);
				$this->Produtos_model->update($produto_id[$i], $produto_qtde_estoque);
			}
			
			// criar recurso pdf
			
			redirect('vendas/imprimir/'.$id_venda);
			//echo '<pre>'; print_r($this->input->post());  exit();
			
			
		}else{
			
			$data = array(
			'titulo' => 'Venda de Produtos',
			'styles' => array(
				'js/select/select2.min.css',
				'vendor/autocomplete/jquery-ui.css',
				'vendor/autocomplete/estilo.css',
			),
			'scripts' => array(
				'vendor/autocomplete/jquery-migrate.js',
				'vendor/calcx/jquery-calx-sample-2.2.8.min.js',
				'vendor/calcx/venda.js',
				'js/select/select2.min.js',
				'js/select/custom.js',
				'vendor/sweetalert2/sweetalert2.js',
				'vendor/autocomplete/jquery-ui.js',
			),
			'clientes' => $this->Core_model->get_all('clientes', array('cliente_ativo' => 1)),
			'formas_pagamentos' => $this->Core_model->get_all('formas_pagamentos', array('forma_pagamento_ativa' => 1)),
			'vendedores' => $this->Core_model->get_all('vendedores', array('vendedor_ativo' => 1)),
			);

			
			
			$this->load->view('_includes/header', $data);
			$this->load->view('vendas/add');
			$this->load->view('_includes/footer');	
			
		}
	}
	
	
	public function edit($venda_id = NULL){
		
		if(!$venda_id || !$this->Core_model->get_by_id('vendas', array('venda_id' => $venda_id))){
			$this->session->set_flashdata('error', 'Venda não existe!');
			redirect('vendas');
		}else{
			
				

			$this->form_validation->set_rules('venda_cliente_id', '','required');
			$this->form_validation->set_rules('venda_tipo', '','required');
			
			$this->form_validation->set_rules('venda_valor_total', '','required');
			$this->form_validation->set_rules('venda_vendedor_id', '','required');
			
			
				$venda_produtos = $data['venda_produtos'] = $this->Vendas_model->get_all_produtos_by_venda($venda_id);
		
			
			if($this->form_validation->run()){
				$venda_valor_total = str_replace('R$', '', trim($this->input->post('venda_valor_total')));
				
				$data = elements(
					array(
						'venda_cliente_id',
						'venda_forma_pagamento_id',
						'venda_tipo',
						'venda_vendedor_id',
						'venda_valor_desconto',
						'venda_valor_total',
					),$this->input->post()
				);
				
				$data['venda_valor_total'] = trim(preg_replace('/\$/', '', $venda_valor_total));
				$data = html_escape($data);
				
				$this->Core_model->update('vendas', $data, array('venda_id' => $venda_id));
				
				// deletando de ordem_tem_servico, os serviços antigos da ordem editada
				 
				$this->Vendas_model->delete_old_products($venda_id);
				$produto_id = $this->input->post('produto_id');
				$produto_quantidade = $this->input->post('produto_quantidade');
				$produto_desconto = str_replace('%', '', $this->input->post('produto_desconto'));
				
				$produto_preco_venda = str_replace('R$', '',  $this->input->post('produto_preco_venda'));
				$produto_item_total = str_replace('R$', '',  $this->input->post('produto_item_total'));
				$produto_preco_venda = str_replace(',', '', $produto_preco_venda);
				$produto_item_total = str_replace(',', '',  $produto_item_total);
				
							 
				$qty_produto = count($produto_id);
				
				$venda_id = $this->input->post('venda_id');
			
				for($i = 0; $i < $qty_produto; $i++){
					
					$data = array(
						'venda_produto_id_venda' => $venda_id,
						'venda_produto_id_produto' => $produto_id[$i],
						'venda_produto_quantidade' => $produto_quantidade[$i],
						'venda_produto_valor_unitario' => $produto_preco_venda[$i],
						'venda_produto_desconto' => $produto_desconto[$i],
						'venda_produto_valor_total' => $produto_item_total[$i],
					);
					
					$data = html_escape($data);
					$this->Core_model->insert('venda_produtos', $data);
					
					
					//atualiza estoque
					foreach($venda_produtos as $venda_p){
						if($venda_p->venda_produto_quantidade < $produto_quantidade[$i]){
							$produto_qtde_estoque = 0;
							// transforma em inteiro o valor que vem do array
							$produto_qtde_estoque += intval($produto_quantidade[$i]);
							
							
							$diferenca = ($produto_qtde_estoque - $venda->venda_produto_quantidade);
							
							$this->Produtos_model->update($produto_id[$i], $diferenca);
						}
					}
					
					
					
				}
				
				// criar recurso pdf
				
				redirect('vendas/imprimir/'.$venda_id);
				//echo '<pre>'; print_r($this->input->post());  exit();
				
				
			}else{
				
				$data = array(
				'titulo' => 'Venda de Produtos',
				'styles' => array(
					'js/select/select2.min.css',
					'vendor/autocomplete/jquery-ui.css',
					'vendor/autocomplete/estilo.css',
				),
				'scripts' => array(
					'vendor/autocomplete/jquery-migrate.js',
					'vendor/calcx/jquery-calx-sample-2.2.8.min.js',
					'vendor/calcx/venda.js',
					'js/select/select2.min.js',
					'js/select/custom.js',
					'vendor/sweetalert2/sweetalert2.js',
					'vendor/autocomplete/jquery-ui.js',
				),
				'clientes' => $this->Core_model->get_all('clientes', array('cliente_ativo' => 1)),
				'formas_pagamentos' => $this->Core_model->get_all('formas_pagamentos', array('forma_pagamento_ativa' => 1)),
				'vendedores' => $this->Core_model->get_all('vendedores', array('vendedor_ativo' => 1)),
				'venda' => $this->Vendas_model->get_by_id($venda_id),
				'venda_produtos' => $this->Vendas_model->get_all_produtos_by_venda($venda_id),
				'desabilitar' => TRUE,
				);
			
				
				
				$this->load->view('_includes/header', $data);
				$this->load->view('vendas/edit');
				$this->load->view('_includes/footer');	
				
			}
		}
		
	}
	
	public function imprimir($venda_id = NULL){
		
		if(!$venda_id || !$this->Core_model->get_by_id('vendas', array('venda_id' => $venda_id))){
			$this->session->set_flashdata('error', 'Venda não existe!');
			redirect('vendas');
		}else{
			
			$data = array(
				'titulo' => 'Escolha uma opção',
				'venda' => $this->Core_model->get_by_id('vendas', array('venda_id' => $venda_id)),
			);
			 
			$this->load->view('_includes/header', $data);
			$this->load->view('vendas/imprimir');
			$this->load->view('_includes/footer');	
			
		}
	}
	
	
		
	public function pdf($venda_id = NULL){
		
		if(!$venda_id || !$this->Core_model->get_by_id('vendas', array('venda_id' => $venda_id))){
			$this->session->set_flashdata('error', 'Venda não existe!');
			redirect('vendas');
		}else{
			
			$empresa = $this->Core_model->get_by_id('sistema', array('sistema_id' => 1));
			$vendas = $this->Vendas_model->get_by_id($venda_id);
			
			
			$file_name = 'Venda&nbsp;'.$vendas->venda_id ;
			
			$html = '<html>';
			$html .= '<head><title>'.$empresa->sistema_nome_fantasia.' - Impressão de Venda</title></head>';
			$html .= '<body style="font-size: 14px;">';
			$html .= '<h4 align="center">
					Razão Social: '.$empresa->sistema_razao_social.'<br>
					CNPJ: '.$empresa->sistema_cnpj.'<br>
					Whatsapp: '.$empresa->sistema_telefone_movel.'<br>
					E-mail: '.$empresa->sistema_email.'<br>
					Site: '.$empresa->sistema_site_url.'
					  </h4> <hr>';
			
			
			$html .= '<p style="text-align: right;">Nº '.$vendas->venda_id.'</p>';
			$html .= '<p>
				Cliente: '.$vendas->cliente_nome_completo.' <br>
				CPF/CNPJ: '.$vendas->cliente_cpf_cnpj.' <br>
				Celular: '.$vendas->cliente_celular.' <br>
				Data de Emissão: ' .formata_data_banco_sem_hora($vendas->venda_data_emissao). ' <br>
				Forma Pagamento: '.$vendas->forma_pagamento_nome.'				
			</p>';
			$html .= '<hr>';
			$html .= '<table width="100%">';
			$html .= '<tr><th>Código</th><th>Descrição</th><th>Quantidade</th><th>Valor unitário</th><th>Desconto</th><th>Valor Total</th></tr>';
			$venda_id = $vendas->venda_id;
			$produtos_venda= $this->Vendas_model->get_all_produtos($venda_id);
			$valor_final_venda = $this->Vendas_model->get_valor_final_venda($venda_id);
			
			foreach($produtos_venda as $produtos){
				
				$html .= '<tr>';
				$html .= '<td>'.$produtos->produto_codigo.'</td>';
				$html .= '<td>'.$produtos->produto_descricao.'</td>';
				$html .= '<td>'.$produtos->venda_produto_quantidade.'</td>';
				$html .= '<td>'.$produtos->venda_produto_valor_unitario.'</td>';
				$html .= '<td>'.$produtos->venda_produto_desconto.'</td>';
				$html .= '<td>'.$produtos->venda_produto_valor_total.'</td>';
				
				$html .= '</tr>';
			}
			
			
			$html .= '<tr>';
			$html .= '<th colspan="5"  style="text-align: right;">Valor Total:</th>';
			$html .= '<th>'.$valor_final_venda->venda_produto_valor_total.'</th>';
			$html .= '</tr>';
			$html .= '</table>';
			
			
			
			$html .= '</body></html>';
			// FALSE  ABRE O PDF NO NAVEGADOR
			// TRUE FAZ O DOWNLOAD
			
			$this->pdf->createPDF($html, $file_name, false);	
			
		}
	}



	public function delete($venda_id = NULL){
		if(!$venda_id || !$this->Core_model->get_by_id('vendas', array('venda_id' => $venda_id))){
			$this->session->set_flashdata('error', 'Venda não existe!');
			redirect('vendas');
		}else{
		
			$this->Core_model->delete('vendas', array('venda_id' => $venda_id));
			redirect('vendas');
		}
	}
		
	

}