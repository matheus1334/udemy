<?php 

defined('BASEPATH') OR exit ('Ação não permitida.');

Class Categoria extends CI_Controller{
	
	public function _construct(){
		parent::_construct();
	
		//definir se há sessão
		if(!$this->ion_auth->logged_in()){
			$this->session->set_flashdata('info', 'Sua sessão expirou.');
			redirect('login');
		}
		
	}
	
	public function index(){
		$data = array(
			'titulo' => 'Categorias Cadastrados',
			'styles' => array(
				'vendor/datatables/dataTables.bootstrap4.min.css',
			),
			'scripts' => array(
				'vendor/datatables/jquery.dataTables.min.js',
				'vendor/datatables/dataTables.bootstrap4.min.js',
				'vendor/datatables/app.js',
			),
			'categorias' => $this->Core_model->get_all('categorias')
		);
			
		
			$this->load->view('_includes/header', $data);
			$this->load->view('categorias/index');
			$this->load->view('_includes/footer');
	}
	
	public function add(){
		$this->form_validation->set_rules('categoria_nome', '', 'trim|required|max_length[45]|is_unique[categorias.categoria_nome]');				
								
		if($this->form_validation->run()){
			$data = elements(
				array(
				 	'categoria_ativa',
					'categoria_nome'
				), $this->input->post()
			);
			
			$data = html_escape($data);
		
			$this->Core_model->insert('categorias', $data);
			
			redirect('categoria');
		
		}else{
			
			$data = array(
				'titulo' => 'Editar categoria',
				'styles' => array(
					'vendor/datatables/dataTables.bootstrap4.min.css',
				),
				'scripts' => array(
					'js/app.js',
					'js/jquery.mask.min.js'
				),
			);	
			
		
		
		
			$this->load->view('_includes/header', $data);
			$this->load->view('categorias/add');
			$this->load->view('_includes/footer');
		
		}
	}
	
	public function edit($categoria_id = NULL){
		
		if(!$categoria_id || !$this->Core_model->get_by_id('categorias', array('categoria_id' => $categoria_id))){
			$this->session->set_flashdata('error', 'categoria não existe!');
			redirect('categoria');
		}else{
			
			$this->form_validation->set_rules('categoria_nome', '', 'trim|required|max_length[45]|callback_check_nome_categoria');				
								
			if($this->form_validation->run()){
				
				$categoria_ativa = $this->input->post('categoria_ativa');
				
				if($this->db->table_exists('produtos')){
					 if($categoria_ativa == 2 && $this->Core_model->get_by_id('produtos', array('produto_categoria_id' => $categoria_id, 'produto_ativo' =>1))){
						$this->session->set_flashdata('error', 'Esta categoria não pode ser desativada, pois está sendo utilizada em Produtos');					 				redirect('categoria');
					 }
				}
				
				
				
				$data = elements(
					array(
					 	'categoria_ativa',
						'categoria_nome'
					), $this->input->post()
				);
				
				$data = html_escape($data);
			
				$this->Core_model->update('categorias', $data, array('categoria_id' => $categoria_id));
				
				redirect('categoria');
			
			}else{
				
				$data = array(
					'titulo' => 'Editar categoria',
					'styles' => array(
						'vendor/datatables/dataTables.bootstrap4.min.css',
					),
					'scripts' => array(
						'js/app.js',
						'js/jquery.mask.min.js'
					),
					
					'categorias' => $this->Core_model->get_by_id('categorias', array('categoria_id' => $categoria_id))
				);	
				
			
			
			
				$this->load->view('_includes/header', $data);
				$this->load->view('categorias/edit');
				$this->load->view('_includes/footer');
			
			}
			
		}	
		
		
	}
	
	
	public function delete($categoria_id = NULL){
		
		if(!$categoria_id || !$this->Core_model->get_by_id('categorias', array('categoria_id' => $categoria_id))){
			$this->session->set_flashdata('error', 'categoria não existe!');
			redirect('categoria');
		}else{
			$this->Core_model->update('categorias', array('categoria_ativa' => 2), array('categoria_id' => $categoria_id));
			redirect('categoria');
		}
		
	}
	
	public function check_nome_categoria($categoria_nome){
		$categoria_id = $this->input->post('categoria_id');
		if($this->Core_model->get_by_id('categorias', array('categoria_nome' => $categoria_nome, 'categoria_id !=' => $categoria_id ))){
			$this->form_validation->set_message('check_nome_categoria', 'Está categoria já existe');
			return FALSE;
		}else{
			return TRUE;	
		}
	}
	
}