<?php 

defined('BASEPATH') OR exit ('Ação não permitida.');

Class Relatorios extends CI_Controller{
	
	public function __construct(){
		parent::__construct();
	
		//definir se há sessão
		if(!$this->ion_auth->logged_in()){
			$this->session->set_flashdata('info', 'Sua sessão expirou.');
			redirect('login');
		}
		
		$this->load->model('Vendas_model');
		$this->load->model('Ordem_model');
		$this->load->model('Financeiro_model');
		if(!$this->ion_auth->is_admin()){
			$this->session->set_flashdata('error', 'Você não tem permissão de acesso desta página!');
			redirect(); 
		}
		
	}
	
	public function index(){
		redirect();
	}
	
	public function vendas(){
		$data = array(
			'titulo' => 'Relatorios de Vendas'
		);
		
		
		$data_inicial = $this->input->post('data_inicial');
		$data_final = $this->input->post('data_final');
		
		if($data_inicial){
			if($this->Vendas_model->gerar_relatorio_vendas($data_inicial, $data_final)){
				
				// SE HOUVER DATAS MONTAR PDF
					
					$empresa = $this->Core_model->get_by_id('sistema', array('sistema_id' => 1));
					$vendas = $this->Vendas_model->gerar_relatorio_vendas($data_inicial, $data_final);
					
					
					$file_name = 'Relatório de Venda';
					
					$html = '<html>';
					$html .= '<head><title>'.$empresa->sistema_nome_fantasia.' - Relatório de Vendas</title></head>';
					$html .= '<body style="font-size: 14px;">';
					$html .= '<h4 align="center">
							Razão Social: '.$empresa->sistema_razao_social.'<br>
							CNPJ: '.$empresa->sistema_cnpj.'<br>
							Whatsapp: '.$empresa->sistema_telefone_movel.'<br>
							E-mail: '.$empresa->sistema_email.'<br>
							Site: '.$empresa->sistema_site_url.'
							  </h4> <hr>';
					
					
					$html .= '<p>Relatórios de vendas realizadas no périodo de: </p>';
					if($data_inicial && $data_final){
						$html .= '<p>'.formata_data_banco_sem_hora($data_inicial).' - '.formata_data_banco_sem_hora($data_final).'</p>';
					}else{
						$html .= '<p>'.formata_data_banco_sem_hora($data_inicial).'</p>';
					}
					
					/*	
					$html .= '<p>
						Cliente: '.$vendas->cliente_nome_completo.' <br>
						CPF/CNPJ: '.$vendas->cliente_cpf_cnpj.' <br>
						Celular: '.$vendas->cliente_celular.' <br>
						Data de Emissão: ' .formata_data_banco_sem_hora($vendas->venda_data_emissao). ' <br>
						Forma Pagamento: '.$vendas->forma_pagamento_nome.'				
					</p>';*/
					
					$html .= '<hr>';
					$html .= '<table width="100%">';
					$html .= '<tr><th>Venda</th><th>Data</th><th>Cliente</th><th>Pagamento</th><th>Valor Total</th></tr>';
					
					
					//$produtos_venda= $this->Vendas_model->get_all_produtos($venda_id);
					$valor_final_venda = $this->Vendas_model->get_valor_final_relatorio($data_inicial, $data_final);
					
					foreach($vendas as $venda){
						
						$html .= '<tr>';
						$html .= '<td>'.$venda->venda_id.'</td>';
						$html .= '<td>'.formata_data_banco_sem_hora($venda->venda_data_emissao).'</td>';
						$html .= '<td>'.$venda->cliente_nome_completo.'</td>';
						$html .= '<td>'.$venda->forma_pagamento_nome.'</td>';
						$html .= '<td>'.$venda->venda_valor_total.'</td>';
						
						$html .= '</tr>';
					}
					
					
					$html .= '<tr>';
					$html .= '<th colspan="4"  style="text-align: right;">Valor Total:</th>';
					$html .= '<th>'.$valor_final_venda->venda_valor_total.'</th>';
					$html .= '</tr>';
					$html .= '</table>';
					
					
					
					$html .= '</body></html>';
					// FALSE  ABRE O PDF NO NAVEGADOR
					// TRUE FAZ O DOWNLOAD
					
					$this->pdf->createPDF($html, $file_name, false);	
				
			}else{
				if(!empty($data_inicial) && !empty($data_inicial) ){
					$this->session->set_Flashdata('error', 'Não há relatórios de venda nestes períodos!');
					
				}else{
					$this->session->set_Flashdata('error', 'Não há relatórios de venda nestes períodos!');
					
				}
				redirect('relatorios/vendas');					
			} 
		}
		
		
		$this->load->view('_includes/header', $data);
		$this->load->view('relatorios/vendas');
		$this->load->view('_includes/footer');
		
	}
	
	
	
	public function os(){
		$data = array(
			'titulo' => 'Relatorios de Ordens de Serviço'
		);
		
		
		$data_inicial = $this->input->post('data_inicial');
		$data_final = $this->input->post('data_final');
		
		if($data_inicial){
			if($this->Ordem_model->gerar_relatorio_os($data_inicial, $data_final)){
				
				// SE HOUVER DATAS MONTAR PDF
				
				$empresa = $this->Core_model->get_by_id('sistema', array('sistema_id' => 1));
				$ordens = $this->Ordem_model->gerar_relatorio_os($data_inicial, $data_final);
				
				
				$file_name = 'Relatório de Ordem de Serviço';
				
				$html = '<html>';
				$html .= '<head><title>'.$empresa->sistema_nome_fantasia.' - Relatório de Ordem de Serviço</title></head>';
				$html .= '<body style="font-size: 14px;">';
				$html .= '<h4 align="center">
						Razão Social: '.$empresa->sistema_razao_social.'<br>
						CNPJ: '.$empresa->sistema_cnpj.'<br>
						Whatsapp: '.$empresa->sistema_telefone_movel.'<br>
						E-mail: '.$empresa->sistema_email.'<br>
						Site: '.$empresa->sistema_site_url.'
						  </h4> <hr>';
				
				
				$html .= '<p>Relatórios de ordens de serviços realizadas no périodo de: </p>';
				if($data_inicial && $data_final){
					$html .= '<p>'.formata_data_banco_sem_hora($data_inicial).' - '.formata_data_banco_sem_hora($data_final).'</p>';
				}else{
					$html .= '<p>'.formata_data_banco_sem_hora($data_inicial).'</p>';
				}
				
				/*	
				$html .= '<p>
					Cliente: '.$vendas->cliente_nome_completo.' <br>
					CPF/CNPJ: '.$vendas->cliente_cpf_cnpj.' <br>
					Celular: '.$vendas->cliente_celular.' <br>
					Data de Emissão: ' .formata_data_banco_sem_hora($vendas->venda_data_emissao). ' <br>
					Forma Pagamento: '.$vendas->forma_pagamento_nome.'				
				</p>';*/
				
				$html .= '<hr>';
				$html .= '<table width="100%">';
				$html .= '<tr><th>Ordem</th><th>Data</th><th>Cliente</th><th>Pagamento</th><th>Valor Total</th></tr>';
				
				
				//$produtos_venda= $this->Vendas_model->get_all_produtos($venda_id);
				$valor_final_venda = $this->Ordem_model->get_valor_final_relatorio($data_inicial, $data_final);
				
				foreach($ordens as $ordem){
					
					$html .= '<tr>';
					$html .= '<td>'.$ordem->ordem_servico_id.'</td>';
					$html .= '<td>'.formata_data_banco_sem_hora($ordem->ordem_servico_data_emissao).'</td>';
					$html .= '<td>'.$ordem->cliente_nome_completo.'</td>';
					$html .= '<td>'.$ordem->forma_pagamento_nome.'</td>';
					$html .= '<td>'.$ordem->ordem_servico_valor_total.'</td>';
					
					$html .= '</tr>';
				}
				
				
				$html .= '<tr>';
				$html .= '<th colspan="4"  style="text-align: right;">Valor Total:</th>';
				$html .= '<th>'.$valor_final_venda->ordem_servico_valor_total.'</th>';
				$html .= '</tr>';
				$html .= '</table>';
				
				
				
				$html .= '</body></html>';
				// FALSE  ABRE O PDF NO NAVEGADOR
				// TRUE FAZ O DOWNLOAD
				
				$this->pdf->createPDF($html, $file_name, false);	
				
			}else{
				if(!empty($data_inicial) && !empty($data_inicial) ){
					$this->session->set_Flashdata('error', 'Não há relatórios de os nestes períodos!');
					
				}else{
					$this->session->set_Flashdata('error', 'Não há relatórios de os nestes períodos!');
					
				}
				redirect('relatorios/os');					
			} 
		}
		
		
		$this->load->view('_includes/header', $data);
		$this->load->view('relatorios/os');
		$this->load->view('_includes/footer');
		
	}
	
	
	public function receber(){
		$data = array(
			'titulo' => 'Relatorios de Contas a Receber'
		);
		
		
		$contas = $this->input->post('contas');
		
		if($contas == 'vencidas' || $contas == 'pagas' || $contas == 'receber'){
			
			if($contas == 'vencidas'){
				$conta_receber_status = 0;
				$data_vencimento = TRUE;
				
				
				if($this->Financeiro_model->get_contas_receber_relatorio($conta_receber_status, $data_vencimento)){
						
					$empresa = $this->Core_model->get_by_id('sistema', array('sistema_id' => 1));
					$contas = $this->Financeiro_model->get_contas_receber_relatorio($conta_receber_status, $data_vencimento);
					
					
					$file_name = 'Relatório de Contas Vencidas';
					
					$html = '<html>';
					$html .= '<head><title>'.$empresa->sistema_nome_fantasia.' - Relatório de Contas a Receber</title></head>';
					$html .= '<body style="font-size: 14px;">';
					$html .= '<h4 align="center">
							Razão Social: '.$empresa->sistema_razao_social.'<br>
							CNPJ: '.$empresa->sistema_cnpj.'<br>
							Whatsapp: '.$empresa->sistema_telefone_movel.'<br>
							E-mail: '.$empresa->sistema_email.'<br>
							Site: '.$empresa->sistema_site_url.'
							  </h4> <hr>';
					
					
					$html .= '<p>Relatórios de Contas a Receber no périodo de: </p>';
					
					$html .= '<hr>';
					$html .= '<table width="100%">';
					$html .= '<tr><th>Venda</th><th>Data</th><th>Cliente</th><th>Situação</th><th>Valor Total</th></tr>';
					
					
					//$produtos_venda= $this->Vendas_model->get_all_produtos($venda_id);
					$valor_final_venda = $this->Financeiro_model->get_sum_contas_receber_relatorio($conta_receber_status, $data_vencimento);
					
					foreach($contas as $venda){
						
						$html .= '<tr>';
						$html .= '<td>'.$venda->conta_receber_id.'</td>';
						$html .= '<td>'.formata_data_banco_sem_hora($venda->conta_receber_data_vencto).'</td>';
						$html .= '<td>'.$venda->cliente_nome_completo.'</td>';
						$html .= '<td>Vencida</td>';
						$html .= '<td>'.$venda->conta_receber_valor.'</td>';
						
						$html .= '</tr>';
					}
					
					
					$html .= '<tr>';
					$html .= '<th colspan="4"  style="text-align: right;">Valor Total:</th>';
					$html .= '<th>'.$valor_final_venda->conta_receber_valor.'</th>';
					$html .= '</tr>';
					$html .= '</table>';
					
					
					
					$html .= '</body></html>';
					// FALSE  ABRE O PDF NO NAVEGADOR
					// TRUE FAZ O DOWNLOAD
					
					$this->pdf->createPDF($html, $file_name, false);	
					
				}else{
					$this->session->set_Flashdata('error', 'Não há contas a receber vencidas!');
					redirect('relatorios/receber');
				}
				
			}
			
			// contas pagas
			
			if($contas == 'pagas'){
				$conta_receber_status = 1;
				
				
				if($this->Financeiro_model->get_contas_receber_relatorio($conta_receber_status)){
						
					$empresa = $this->Core_model->get_by_id('sistema', array('sistema_id' => 1));
					$contas = $this->Financeiro_model->get_contas_receber_relatorio($conta_receber_status);
					
					
					$file_name = 'Relatório de Contas Pagas';
					
					$html = '<html>';
					$html .= '<head><title>'.$empresa->sistema_nome_fantasia.' - Relatório de Contas a Receber</title></head>';
					$html .= '<body style="font-size: 14px;">';
					$html .= '<h4 align="center">
							Razão Social: '.$empresa->sistema_razao_social.'<br>
							CNPJ: '.$empresa->sistema_cnpj.'<br>
							Whatsapp: '.$empresa->sistema_telefone_movel.'<br>
							E-mail: '.$empresa->sistema_email.'<br>
							Site: '.$empresa->sistema_site_url.'
							  </h4> <hr>';
					
					
					$html .= '<p>Relatórios de Contas a Receber no périodo de: </p>';
					
					$html .= '<hr>';
					$html .= '<table width="100%">';
					$html .= '<tr><th>Venda</th><th>Data Pagamento</th><th>Cliente</th><th>Situação</th><th>Valor Total</th></tr>';
					
					
					//$produtos_venda= $this->Vendas_model->get_all_produtos($venda_id);
					$valor_final_venda = $this->Financeiro_model->get_sum_contas_receber_relatorio($conta_receber_status);
					
					foreach($contas as $venda){
						
						$html .= '<tr>';
						$html .= '<td>'.$venda->conta_receber_id.'</td>';
						$html .= '<td>'.formata_data_banco_sem_hora($venda->conta_receber_data_pagamento).'</td>';
						$html .= '<td>'.$venda->cliente_nome_completo.'</td>';
						$html .= '<td>Paga</td>';
						$html .= '<td>'.$venda->conta_receber_valor.'</td>';
						
						$html .= '</tr>';
					}
					
					
					$html .= '<tr>';
					$html .= '<th colspan="4"  style="text-align: right;">Valor Total:</th>';
					$html .= '<th>'.$valor_final_venda->conta_receber_valor.'</th>';
					$html .= '</tr>';
					$html .= '</table>';
					
					
					
					$html .= '</body></html>';
					// FALSE  ABRE O PDF NO NAVEGADOR
					// TRUE FAZ O DOWNLOAD
					
					$this->pdf->createPDF($html, $file_name, false);	
					
				}else{
					$this->session->set_Flashdata('error', 'Não há contas pagas!');
					redirect('relatorios/receber');
				}
				
			}
			
			// contas receber não vencidas
			
			if($contas == 'receber'){
				$conta_receber_status = 0;
				
				
				if($this->Financeiro_model->get_contas_receber_relatorio($conta_receber_status)){
						
					$empresa = $this->Core_model->get_by_id('sistema', array('sistema_id' => 1));
					$contas = $this->Financeiro_model->get_contas_receber_relatorio($conta_receber_status);
					
					
					$file_name = 'Relatório de Contas Receber';
					
					$html = '<html>';
					$html .= '<head><title>'.$empresa->sistema_nome_fantasia.' - Relatório de Contas a Receber</title></head>';
					$html .= '<body style="font-size: 14px;">';
					$html .= '<h4 align="center">
							Razão Social: '.$empresa->sistema_razao_social.'<br>
							CNPJ: '.$empresa->sistema_cnpj.'<br>
							Whatsapp: '.$empresa->sistema_telefone_movel.'<br>
							E-mail: '.$empresa->sistema_email.'<br>
							Site: '.$empresa->sistema_site_url.'
							  </h4> <hr>';
					
					
					$html .= '<p>Relatórios de Contas a Receber no périodo de: </p>';
					
					$html .= '<hr>';
					$html .= '<table width="100%">';
					$html .= '<tr><th>Venda</th><th>Vencimento</th><th>Cliente</th><th>Situação</th><th>Valor Total</th></tr>';
					
					
					//$produtos_venda= $this->Vendas_model->get_all_produtos($venda_id);
					$valor_final_venda = $this->Financeiro_model->get_sum_contas_receber_relatorio($conta_receber_status);
					
					foreach($contas as $venda){
						
						$html .= '<tr>';
						$html .= '<td>'.$venda->conta_receber_id.'</td>';
						$html .= '<td>'.formata_data_banco_sem_hora($venda->conta_receber_data_vencto).'</td>';
						$html .= '<td>'.$venda->cliente_nome_completo.'</td>';
						$html .= '<td>A receber</td>';
						$html .= '<td>'.$venda->conta_receber_valor.'</td>';
						
						$html .= '</tr>';
					}
					
					
					$html .= '<tr>';
					$html .= '<th colspan="4"  style="text-align: right;">Valor Total:</th>';
					$html .= '<th>'.$valor_final_venda->conta_receber_valor.'</th>';
					$html .= '</tr>';
					$html .= '</table>';
					
					
					
					$html .= '</body></html>';
					// FALSE  ABRE O PDF NO NAVEGADOR
					// TRUE FAZ O DOWNLOAD
					
					$this->pdf->createPDF($html, $file_name, false);	
					
				}else{
					$this->session->set_Flashdata('error', 'Não há contas a receber!');
					redirect('relatorios/receber');
				}
				
			}
			
			
		}
		
		$this->load->view('_includes/header', $data);
		$this->load->view('relatorios/receber');
		$this->load->view('_includes/footer');
		
	}
	
	
	
	
	public function pagar(){
		$data = array(
			'titulo' => 'Relatorios de Contas a Pagar'
		);
		
		
		$contas = $this->input->post('contas');
		
		if($contas == 'pagar' || $contas == 'vencidas' || $contas == 'a_pagar'){
			
			if($contas == 'vencidas'){
				$conta_pagar_status = 0;
				$data_vencimento = TRUE;
				
				
				if($this->Financeiro_model->get_contas_pagar_relatorio($conta_pagar_status, $data_vencimento)){
						
					$empresa = $this->Core_model->get_by_id('sistema', array('sistema_id' => 1));
					$contas = $this->Financeiro_model->get_contas_pagar_relatorio($conta_pagar_status, $data_vencimento);
					
					
					$file_name = 'Relatório de Contas a Pagar Vencidas';
					
					$html = '<html>';
					$html .= '<head><title>'.$empresa->sistema_nome_fantasia.' - Relatório de Contas a Pagar</title></head>';
					$html .= '<body style="font-size: 14px;">';
					$html .= '<h4 align="center">
							Razão Social: '.$empresa->sistema_razao_social.'<br>
							CNPJ: '.$empresa->sistema_cnpj.'<br>
							Whatsapp: '.$empresa->sistema_telefone_movel.'<br>
							E-mail: '.$empresa->sistema_email.'<br>
							Site: '.$empresa->sistema_site_url.'
							  </h4> <hr>';
					
					
					$html .= '<p>Relatórios de Contas a Pagar no périodo de: </p>';
					
					$html .= '<hr>';
					$html .= '<table width="100%">';
					$html .= '<tr><th>Venda</th><th>Data</th><th>Fornecedor</th><th>Situação</th><th>Valor Total</th></tr>';
					
					
					//$produtos_venda= $this->Vendas_model->get_all_produtos($venda_id);
					$valor_final_venda = $this->Financeiro_model->get_sum_contas_pagar_relatorio($conta_pagar_status, $data_vencimento);
					
					foreach($contas as $venda){
						
						$html .= '<tr>';
						$html .= '<td>'.$venda->conta_pagar_id.'</td>';
						$html .= '<td>'.formata_data_banco_sem_hora($venda->conta_pagar_data_vencto).'</td>';
						$html .= '<td>'.$venda->fornecedor_nome_fantasia.'</td>';
						$html .= '<td>Vencida</td>';
						$html .= '<td>'.$venda->conta_pagar_valor.'</td>';
						
						$html .= '</tr>';
					}
					
					
					$html .= '<tr>';
					$html .= '<th colspan="4"  style="text-align: right;">Valor Total:</th>';
					$html .= '<th>'.$valor_final_venda->conta_pagar_valor.'</th>';
					$html .= '</tr>';
					$html .= '</table>';
					
					
					
					$html .= '</body></html>';
					// FALSE  ABRE O PDF NO NAVEGADOR
					// TRUE FAZ O DOWNLOAD
					
					$this->pdf->createPDF($html, $file_name, false);	
					
				}else{
					$this->session->set_Flashdata('error', 'Não há contas a pagar vencidas!');
					redirect('relatorios/pagar');
				}
				
			}
			
			// contas pagas
			
			if($contas == 'pagar'){
				$conta_pagar_status = 1;
				
				
				if($this->Financeiro_model->get_contas_pagar_relatorio($conta_pagar_status)){
						
					$empresa = $this->Core_model->get_by_id('sistema', array('sistema_id' => 1));
					$contas = $this->Financeiro_model->get_contas_pagar_relatorio($conta_pagar_status);
					
					
					$file_name = 'Relatório de Contas a Pagar pagas';
					
					$html = '<html>';
					$html .= '<head><title>'.$empresa->sistema_nome_fantasia.' - Relatório de Contas a Pagar</title></head>';
					$html .= '<body style="font-size: 14px;">';
					$html .= '<h4 align="center">
							Razão Social: '.$empresa->sistema_razao_social.'<br>
							CNPJ: '.$empresa->sistema_cnpj.'<br>
							Whatsapp: '.$empresa->sistema_telefone_movel.'<br>
							E-mail: '.$empresa->sistema_email.'<br>
							Site: '.$empresa->sistema_site_url.'
							  </h4> <hr>';
					
					
					$html .= '<p>Relatórios de Contas a Pagar no périodo de: </p>';
					
					$html .= '<hr>';
					$html .= '<table width="100%">';
					$html .= '<tr><th>Venda</th><th>Data Pagamento</th><th>Cliente</th><th>Situação</th><th>Valor Total</th></tr>';
					
					
					//$produtos_venda= $this->Vendas_model->get_all_produtos($venda_id);
					$valor_final_venda = $this->Financeiro_model->get_sum_contas_pagar_relatorio($conta_pagar_status);
					
					foreach($contas as $venda){
						
						$html .= '<tr>';
						$html .= '<td>'.$venda->conta_pagar_id .'</td>';
						$html .= '<td>'.formata_data_banco_sem_hora($venda->conta_pagar_data_pagamento).'</td>';
						$html .= '<td>'.$venda->fornecedor_nome_fantasia.'</td>';
						$html .= '<td>Paga</td>';
						$html .= '<td>'.$venda->conta_pagar_valor.'</td>';
						
						$html .= '</tr>';
					}
					
					
					$html .= '<tr>';
					$html .= '<th colspan="4"  style="text-align: right;">Valor Total:</th>';
					$html .= '<th>'.$valor_final_venda->conta_pagar_valor.'</th>';
					$html .= '</tr>';
					$html .= '</table>';
					
					
					
					$html .= '</body></html>';
					// FALSE  ABRE O PDF NO NAVEGADOR
					// TRUE FAZ O DOWNLOAD
					
					$this->pdf->createPDF($html, $file_name, false);	
					
				}else{
					$this->session->set_Flashdata('error', 'Não há contas pagas!');
					redirect('relatorios/pagar');
				}
				
			}
			
			// contas receber não vencidas
			
			if($contas == 'a_pagar'){
				$conta_pagar_status = 0;
				
				
				if($this->Financeiro_model->get_contas_pagar_relatorio($conta_pagar_status)){
						
					$empresa = $this->Core_model->get_by_id('sistema', array('sistema_id' => 1));
					$contas = $this->Financeiro_model->get_contas_pagar_relatorio($conta_pagar_status);
					
					
					$file_name = 'Relatório de Contas a Pagar';
					
					$html = '<html>';
					$html .= '<head><title>'.$empresa->sistema_nome_fantasia.' - Relatório de Contas a Pagar</title></head>';
					$html .= '<body style="font-size: 14px;">';
					$html .= '<h4 align="center">
							Razão Social: '.$empresa->sistema_razao_social.'<br>
							CNPJ: '.$empresa->sistema_cnpj.'<br>
							Whatsapp: '.$empresa->sistema_telefone_movel.'<br>
							E-mail: '.$empresa->sistema_email.'<br>
							Site: '.$empresa->sistema_site_url.'
							  </h4> <hr>';
					
					
					$html .= '<p>Relatórios de Contas a Pagar no período de: </p>';
					
					$html .= '<hr>';
					$html .= '<table width="100%">';
					$html .= '<tr><th>Venda</th><th>Vencimento</th><th>Cliente</th><th>Situação</th><th>Valor Total</th></tr>';
					
					
					//$produtos_venda= $this->Vendas_model->get_all_produtos($venda_id);
					$valor_final_venda = $this->Financeiro_model->get_sum_contas_pagar_relatorio($conta_pagar_status);
					
					foreach($contas as $venda){
						
						$html .= '<tr>';
						$html .= '<td>'.$venda->conta_pagar_id .'</td>';
						$html .= '<td>'.formata_data_banco_sem_hora($venda->conta_pagar_data_vencto).'</td>';
						$html .= '<td>'.$venda->fornecedor_nome_fantasia.'</td>';
						$html .= '<td>A receber</td>';
						$html .= '<td>'.$venda->conta_pagar_valor.'</td>';
						
						$html .= '</tr>';
					}
					
					
					$html .= '<tr>';
					$html .= '<th colspan="4"  style="text-align: right;">Valor Total:</th>';
					$html .= '<th>'.$valor_final_venda->conta_pagar_valor.'</th>';
					$html .= '</tr>';
					$html .= '</table>';
					
					
					
					$html .= '</body></html>';
					// FALSE  ABRE O PDF NO NAVEGADOR
					// TRUE FAZ O DOWNLOAD
					
					$this->pdf->createPDF($html, $file_name, false);	
					
				}else{
					$this->session->set_Flashdata('error', 'Não há contas a receber!');
					redirect('relatorios/pagar');
				}
				
			}
			
			
		}
		
		$this->load->view('_includes/header', $data);
		$this->load->view('relatorios/pagar');
		$this->load->view('_includes/footer');
		
	}
	
	
}