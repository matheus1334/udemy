<?php 

defined('BASEPATH') OR exit ('Ação não permitida.');

Class Formas_pagamentos extends CI_Controller{
	
	public function __construct(){
		parent::__construct();
	
		//definir se há sessão
		if(!$this->ion_auth->logged_in()){
			$this->session->set_flashdata('info', 'Sua sessão expirou.');
			redirect('login');
		}		
		if(!$this->ion_auth->is_admin()){
			$this->session->set_flashdata('error', 'Você não tem permissão de acesso desta página!');
			redirect(); 
		}
	}
	
	public function index(){
		$data = array(
			'titulo' => 'Formas Pagamento',
			'styles' => array(
				'vendor/datatables/dataTables.bootstrap4.min.css',
			),
			'scripts' => array(
				'vendor/datatables/jquery.dataTables.min.js',
				'vendor/datatables/dataTables.bootstrap4.min.js',
				'vendor/datatables/app.js',
			),
			'formas_pagamentos' => $this->Core_model->get_all('formas_pagamentos'),
		);
			
		
			$this->load->view('_includes/header', $data);
			$this->load->view('formas_pagamentos/index');
			$this->load->view('_includes/footer');
	}
	
	public function add(){

		$this->form_validation->set_rules('forma_pagamento_nome', '', 'required');
		$this->form_validation->set_rules('forma_pagamento_aceita_parc', '', 'required');
		
		
		
		if($this->form_validation->run()){
			
			$data = elements(
				array(
					'forma_pagamento_nome',
					'forma_pagamento_aceita_parc',
					'forma_pagamento_ativa',
				), $this->input->post()
			);
			
			
			$data = html_escape($data);
			$this->Core_model->insert('formas_pagamentos', $data);
			redirect('formas_pagamentos');
		}else{
			
			$data = array(
				'titulo' => 'Cadastrar Forma Pagamento',
				'styles' => array(
					'js/select/select2.min.css',
				),
				'scripts' => array(
					'js/select/select2.min.js',
					'js/select/custom.js',
					'js/app.js',
					'js/jquery.mask.min.js'
				),
				
			);

			$this->load->view('_includes/header', $data);
			$this->load->view('formas_pagamentos/add');
			$this->load->view('_includes/footer');
			
		}
	}
	
	public function edit($forma_pagamento_id = NULl){
		if(!$forma_pagamento_id || !$this->Core_model->get_by_id('formas_pagamentos', array('forma_pagamento_id' => $forma_pagamento_id))){
			$this->session->set_flashdata('error', 'Forma de Pagamento não encontrada');
			redirect('formas_pagamentos');	
		}else{
			
			$this->form_validation->set_rules('forma_pagamento_nome', '', 'required');
			$this->form_validation->set_rules('forma_pagamento_aceita_parc', '', 'required');
			
			
			
			if($this->form_validation->run()){
				
				$data = elements(
					array(
						'forma_pagamento_nome',
						'forma_pagamento_aceita_parc',
						'forma_pagamento_ativa',
					), $this->input->post()
				);
				
				
				$data = html_escape($data);
				$this->Core_model->update('formas_pagamentos', $data, array('forma_pagamento_id' => $forma_pagamento_id));
				redirect('formas_pagamentos');
			}else{
				
				$data = array(
					'titulo' => 'Editar Forma Pagamento',
					'styles' => array(
						'js/select/select2.min.css',
					),
					'scripts' => array(
						'js/select/select2.min.js',
						'js/select/custom.js',
						'js/app.js',
						'js/jquery.mask.min.js'
					),
					'formas_pagamentos' => $this->Core_model->get_by_id('formas_pagamentos', array('forma_pagamento_id' => $forma_pagamento_id))
				);

				$this->load->view('_includes/header', $data);
				$this->load->view('formas_pagamentos/edit');
				$this->load->view('_includes/footer');
				
			}
		}
	}
	public function delete($forma_pagamento_id = NULL){
		
		if(!$forma_pagamento_id || !$this->Core_model->get_by_id('formas_pagamentos', array('forma_pagamento_id' => $forma_pagamento_id))){
			$this->session->set_flashdata('error', 'Forma de pagamento não existe!');
			redirect('formas_pagamentos');
		}else{
			$this->Core_model->delete('formas_pagamentos', array('forma_pagamento_id' => $forma_pagamento_id));
			redirect('formas_pagamentos');
		}
		
	}
}