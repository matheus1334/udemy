<?php 

defined('BASEPATH') OR exit ('Ação não permitida.');

Class Marca extends CI_Controller{
	
	public function _construct(){
		parent::_construct();
	
		//definir se há sessão
		if(!$this->ion_auth->logged_in()){
			$this->session->set_flashdata('info', 'Sua sessão expirou.');
			redirect('login');
		}
		
	}
	
	public function index(){
		$data = array(
			'titulo' => 'Marcas Cadastrados',
			'styles' => array(
				'vendor/datatables/dataTables.bootstrap4.min.css',
			),
			'scripts' => array(
				'vendor/datatables/jquery.dataTables.min.js',
				'vendor/datatables/dataTables.bootstrap4.min.js',
				'vendor/datatables/app.js',
			),
			'marcas' => $this->Core_model->get_all('marcas')
		);
			
		
			$this->load->view('_includes/header', $data);
			$this->load->view('marcas/index');
			$this->load->view('_includes/footer');
	}
	
	public function add(){
		$this->form_validation->set_rules('marca_nome', '', 'trim|required|max_length[45]|is_unique[marcas.marca_nome]');				
								
		if($this->form_validation->run()){
			$data = elements(
				array(
				 	'marca_ativa',
					'marca_nome'
				), $this->input->post()
			);
			
			$data = html_escape($data);
		
			$this->Core_model->insert('marcas', $data);
			
			redirect('marca');
		
		}else{
			
			$data = array(
				'titulo' => 'Editar marca',
				'styles' => array(
					'vendor/datatables/dataTables.bootstrap4.min.css',
				),
				'scripts' => array(
					'js/app.js',
					'js/jquery.mask.min.js'
				),
			);	
			
		
		
		
			$this->load->view('_includes/header', $data);
			$this->load->view('marcas/add');
			$this->load->view('_includes/footer');
		
		}
	}
	
	public function edit($marca_id = NULL){
		
		if(!$marca_id || !$this->Core_model->get_by_id('marcas', array('marca_id' => $marca_id))){
			$this->session->set_flashdata('error', 'marca não existe!');
			redirect('marca');
		}else{
			
			$this->form_validation->set_rules('marca_nome', '', 'trim|required|max_length[45]|callback_check_nome_marca');				
								
			if($this->form_validation->run()){
				
				$marca_ativa = $this->input->post('marca_ativa');
				
				if($this->db->table_exists('produtos')){
					 if($marca_ativa == 2 && $this->Core_model->get_by_id('produtos', array('produto_marca_id' => $marca_id, 'produto_ativo' =>1))){
						$this->session->set_flashdata('error', 'Esta marca não pode ser desativada, pois está sendo utilizada em Produtos');					 				redirect('marca');
					 }
				}
				
				$data = elements(
					array(
					 	'marca_ativa',
						'marca_nome'
					), $this->input->post()
				);
				
				$data = html_escape($data);
			
				$this->Core_model->update('marcas', $data, array('marca_id' => $marca_id));
				
				redirect('marca');
			
			}else{
				
				$data = array(
					'titulo' => 'Editar marca',
					'styles' => array(
						'vendor/datatables/dataTables.bootstrap4.min.css',
					),
					'scripts' => array(
						'js/app.js',
						'js/jquery.mask.min.js'
					),
					
					'marcas' => $this->Core_model->get_by_id('marcas', array('marca_id' => $marca_id))
				);	
				
			
			
			
				$this->load->view('_includes/header', $data);
				$this->load->view('marcas/edit');
				$this->load->view('_includes/footer');
			
			}
			
		}	
		
		
	}
	
	
	public function delete($marca_id = NULL){
		
		if(!$marca_id || !$this->Core_model->get_by_id('marcas', array('marca_id' => $marca_id))){
			$this->session->set_flashdata('error', 'marca não existe!');
			redirect('marca');
		}else{
			$this->Core_model->update('marcas', array('marca_ativa' => 2), array('marca_id' => $marca_id));
			redirect('marca');
		}
		
	}
	
	public function check_nome_marca($marca_nome){
		$marca_id = $this->input->post('marca_id');
		if($this->Core_model->get_by_id('marcas', array('marca_nome' => $marca_nome, 'marca_id !=' => $marca_id ))){
			$this->form_validation->set_message('check_nome_marca', 'Está marca já existe');
			return FALSE;
		}else{
			return TRUE;	
		}
	}
	
}