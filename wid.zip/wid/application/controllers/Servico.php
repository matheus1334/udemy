<?php 

defined('BASEPATH') OR exit ('Ação não permitida.');

Class Servico extends CI_Controller{
	
	public function _construct(){
		parent::_construct();
	
		//definir se há sessão
		if(!$this->ion_auth->logged_in()){
			$this->session->set_flashdata('info', 'Sua sessão expirou.');
			redirect('login');
		}
		
	}
	
	public function index(){
		$data = array(
			'titulo' => 'Serviços Cadastrados',
			'styles' => array(
				'vendor/datatables/dataTables.bootstrap4.min.css',
			),
			'scripts' => array(
				'vendor/datatables/jquery.dataTables.min.js',
				'vendor/datatables/dataTables.bootstrap4.min.js',
				'vendor/datatables/app.js',
			),
			'servicos' => $this->Core_model->get_all('servicos')
		);
			
		
			$this->load->view('_includes/header', $data);
			$this->load->view('servicos/index');
			$this->load->view('_includes/footer');
	}
	
	public function add(){
		$this->form_validation->set_rules('servico_nome', '', 'trim|required|max_length[145]');
		$this->form_validation->set_rules('servico_preco', '', 'trim|required');
		$this->form_validation->set_rules('servico_descricao', '', 'trim|required|max_length[500]');					
							
		if($this->form_validation->run()){
			$data = elements(
				array(
				 	'servico_ativo',
					'servico_nome',
					'servico_preco',
					'servico_descricao'
				), $this->input->post()
			);
			
			$data = html_escape($data);
		
			$this->Core_model->insert('servicos', $data);
			
			redirect('servico');
		
		}else{
			
			$data = array(
				'titulo' => 'Editar servico',
				'styles' => array(
					'vendor/datatables/dataTables.bootstrap4.min.css',
				),
				'scripts' => array(
					'js/app.js',
					'js/jquery.mask.min.js'
				),
				
			);	
			
		
		
		
			$this->load->view('_includes/header', $data);
			$this->load->view('servicos/add');
			$this->load->view('_includes/footer');
		
		}
	}
	
	public function edit($servico_id = NULL){
		
		if(!$servico_id || !$this->Core_model->get_by_id('servicos', array('servico_id' => $servico_id))){
			$this->session->set_flashdata('error', 'servico não existe!');
			redirect('servico');
		}else{
			
			$this->form_validation->set_rules('servico_nome', '', 'trim|required|max_length[145]');
			$this->form_validation->set_rules('servico_preco', '', 'trim|required');
			$this->form_validation->set_rules('servico_descricao', '', 'max_length[500]');					
								
			if($this->form_validation->run()){
				$data = elements(
					array(
					 	'servico_ativo',
						'servico_nome',
						'servico_preco',
						'servico_descricao'
					), $this->input->post()
				);
				
				$data = html_escape($data);
			
				$this->Core_model->update('servicos', $data, array('servico_id' => $servico_id));
				
				redirect('servico');
			
			}else{
				
				$data = array(
					'titulo' => 'Editar servico',
					'styles' => array(
						'vendor/datatables/dataTables.bootstrap4.min.css',
					),
					'scripts' => array(
						'js/app.js',
						'js/jquery.mask.min.js'
					),
					
					'servicos' => $this->Core_model->get_by_id('servicos', array('servico_id' => $servico_id))
				);	
				
			
			
			
				$this->load->view('_includes/header', $data);
				$this->load->view('servicos/edit');
				$this->load->view('_includes/footer');
			
			}
			
		}	
		
		
	}
	
	
	public function delete($servico_id = NULL){
		
		if(!$servico_id || !$this->Core_model->get_by_id('servicos', array('servico_id' => $servico_id))){
			$this->session->set_flashdata('error', 'Servico não existe!');
			redirect('servico');
		}else{
			$this->Core_model->update('servicos', array('servico_ativo' => 2), array('servico_id' => $servico_id));
			redirect('servico');
		}
		
	}
	
}