<?php 

defined('BASEPATH') OR exit ('Ação não permitida.');

Class Pagar extends CI_Controller{
	
	public function __construct(){
		parent::__construct();
	
		//definir se há sessão
		if(!$this->ion_auth->logged_in()){
			$this->session->set_flashdata('info', 'Sua sessão expirou.');
			redirect('login');
		}
		$this->load->model('Financeiro_model');
		if(!$this->ion_auth->is_admin()){
			$this->session->set_flashdata('error', 'Você não tem permissão de acesso desta página!');
			redirect(); 
		}
	}
	
	public function index(){
		$data = array(
			'titulo' => 'Contas a Pagar',
			'styles' => array(
				'vendor/datatables/dataTables.bootstrap4.min.css',
			),
			'scripts' => array(
				'vendor/datatables/jquery.dataTables.min.js',
				'vendor/datatables/dataTables.bootstrap4.min.js',
				'vendor/datatables/app.js',
			),
			'contas_pagar' => $this->Financeiro_model->get_all_pagar(),
		);
			
		
			$this->load->view('_includes/header', $data);
			$this->load->view('pagar/index');
			$this->load->view('_includes/footer');
	}
	
	public function add(){

		$this->form_validation->set_rules('conta_pagar_fornecedor_id', '', 'required');
		$this->form_validation->set_rules('conta_pagar_data_vencto', '', 'required');
		$this->form_validation->set_rules('conta_pagar_valor', '', 'required');
		$this->form_validation->set_rules('conta_pagar_obs', '', 'max_length[500]');

		
		if($this->form_validation->run()){
			
			$data = elements(
				array(
					'conta_pagar_fornecedor_id',
					'conta_pagar_data_vencto',
					'conta_pagar_valor',
					'conta_pagar_status',
					'conta_pagar_obs',
				), $this->input->post()
			);
			
			$conta_pagar_status = $this->input->post('conta_pagar_status');
			
			if($conta_pagar_status == 1){
				$data['conta_pagar_data_pagamento'] = date('Y-m-d h:i:s'); 
			}
			
			$data = html_escape($data);
			$this->Core_model->insert('contas_pagar', $data);
			redirect('pagar');
		}else{
			
			$data = array(
				'titulo' => 'Cadastrar Conta',
				'styles' => array(
					'js/select/select2.min.css',
				),
				'scripts' => array(
					'js/select/select2.min.js',
					'js/select/custom.js',
					'js/app.js',
					'js/jquery.mask.min.js'
				),
				'fornecedores' => $this->Core_model->get_all('fornecedores', array('fornecedor_ativo' => 1)),	
			);

			$this->load->view('_includes/header', $data);
			$this->load->view('pagar/add');
			$this->load->view('_includes/footer');
			
		}
	}
	
	public function edit($conta_pagar_id = NULl){
		if(!$conta_pagar_id || !$this->Core_model->get_by_id('contas_pagar', array('conta_pagar_id' => $conta_pagar_id))){
			$this->session->set_flashdata('error', 'Conta não encontrada');
			redirect('pagar');	
		}else{
			
			$this->form_validation->set_rules('conta_pagar_fornecedor_id', '', 'required');
			$this->form_validation->set_rules('conta_pagar_data_vencto', '', 'required');
			$this->form_validation->set_rules('conta_pagar_valor', '', 'required');
			$this->form_validation->set_rules('conta_pagar_obs', '', 'max_length[500]');
			
			
			
			if($this->form_validation->run()){
				
				$data = elements(
					array(
						'conta_pagar_fornecedor_id',
						'conta_pagar_data_vencto',
						'conta_pagar_valor',
						'conta_pagar_status',
						'conta_pagar_obs',
					), $this->input->post()
				);
				
				$conta_pagar_status = $this->input->post('conta_pagar_status');
				
				if($conta_pagar_status == 1){
					$data['conta_pagar_data_pagamento'] = date('Y-m-d h:i:s'); 
				}
				
				$data = html_escape($data);
				$this->Core_model->update('contas_pagar', $data, array('conta_pagar_id' => $conta_pagar_id));
				redirect('pagar');
			}else{
				
				$data = array(
					'titulo' => 'Editar Conta',
					'styles' => array(
						'js/select/select2.min.css',
					),
					'scripts' => array(
						'js/select/select2.min.js',
						'js/select/custom.js',
						'js/app.js',
						'js/jquery.mask.min.js'
					),
					'fornecedores' => $this->Core_model->get_all('fornecedores'),	
					'conta_pagar' => $this->Core_model->get_by_id('contas_pagar', array('conta_pagar_id' => $conta_pagar_id))
				);

				$this->load->view('_includes/header', $data);
				$this->load->view('pagar/edit');
				$this->load->view('_includes/footer');
				
			}
		}
	}
	public function delete($conta_pagar_id = NULL){
		
		if(!$conta_pagar_id || !$this->Core_model->get_by_id('contas_pagar', array('conta_pagar_id' => $conta_pagar_id))){
			$this->session->set_flashdata('error', 'Conta não existe!');
			redirect('pagar');
		}
		if($this->Core_model->get_by_id('contas_pagar', array('conta_pagar_id' => $conta_pagar_id, 'conta_pagar_status' => 0))){
			$this->session->set_flashdata('error', 'Conta ainda esta pendente!');
			redirect('pagar');
		}
		
			$this->Core_model->delete('contas_pagar', array('conta_pagar_id' => $conta_pagar_id));
			redirect('pagar');
		
		
	}
}