<?php 

defined('BASEPATH') OR exit ('Ação não permitida.');

Class Custom_error_404 extends CI_Controller{
	
	public function index(){
		$data = array(
			'Título' => 'Página não encontrada',
		);
		$this->load->view('custom_error_404', $data);
	}
}	