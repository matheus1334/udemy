<?php 

defined('BASEPATH') OR exit ('Ação não permitida.');

Class Fornecedor extends CI_Controller{
	
	public function _construct(){
		parent::_construct();
	
		//definir se há sessão
		if(!$this->ion_auth->logged_in()){
			$this->session->set_flashdata('info', 'Sua sessão expirou.');
			redirect('login');
		}
		
	}
	
	public function index(){
		$data = array(
			'titulo' => 'Fornecedores Cadastrados',
			'styles' => array(
				'vendor/datatables/dataTables.bootstrap4.min.css',
			),
			'scripts' => array(
				'vendor/datatables/jquery.dataTables.min.js',
				'vendor/datatables/dataTables.bootstrap4.min.js',
				'vendor/datatables/app.js',
			),
			'fornecedores' => $this->Core_model->get_all('fornecedores')
		);
			
		
			$this->load->view('_includes/header', $data);
			$this->load->view('fornecedores/index');
			$this->load->view('_includes/footer');
	}
	
	public function add(){
		$this->form_validation->set_rules('fornecedor_razao', '', 'trim|max_length[145]');
		$this->form_validation->set_rules('fornecedor_nome_fantasia', '', 'trim|required|max_length[80]');
		$this->form_validation->set_rules('fornecedor_cnpj', '', 'exact_length[18]|is_unique[fornecedores.fornecedor_cnpj]');
		
		$this->form_validation->set_rules('fornecedor_ie', '', 'trim|max_length[20]');
		$this->form_validation->set_rules('fornecedor_email', '', 'trim|valid_email|max_length[80]');
		$this->form_validation->set_rules('fornecedor_telefone', '', 'trim|max_length[15]');
		$this->form_validation->set_rules('fornecedor_celular', '', 'trim|required|max_length[15]');
		$this->form_validation->set_rules('fornecedor_contato', '', 'trim|max_length[25]');
		$this->form_validation->set_rules('fornecedor_cep', '', 'trim|exact_length[9]');
		$this->form_validation->set_rules('fornecedor_endereco', '', 'trim|required|max_length[80]');
		$this->form_validation->set_rules('fornecedor_numero_endereco', '', 'trim|required|max_length[10]');
		$this->form_validation->set_rules('fornecedor_bairro', '', 'trim|required|max_length[45]');
		$this->form_validation->set_rules('fornecedor_complemento', '', 'trim|max_length[45]');
		
		$this->form_validation->set_rules('fornecedor_cidade', '', 'trim|required|max_length[45]');
		$this->form_validation->set_rules('fornecedor_estado', '', 'trim|required|exact_length[2]');
		$this->form_validation->set_rules('fornecedor_obs', '', 'max_length[500]');					
							
		if($this->form_validation->run()){
			$data = elements(
				array(
				 	'fornecedor_ativo',
					'fornecedor_razao',
					'fornecedor_nome_fantasia',
					'fornecedor_cnpj',
					'fornecedor_ie',
					'fornecedor_email',
					'fornecedor_telefone',
					'fornecedor_celular',
					'fornecedor_contato',
					'fornecedor_cep',
					'fornecedor_endereco',
					'fornecedor_numero_endereco',
					'fornecedor_bairro',
					'fornecedor_cidade',
					'fornecedor_estado',
					'fornecedor_obs'
				), $this->input->post()
			);
			$data['fornecedor_estado'] = strtoupper($this->input->post('fornecedor_estado'));
			$data = html_escape($data);
		
			$this->Core_model->insert('fornecedores', $data);
			
			redirect('fornecedor');
			echo 'validado';
		
		}else{
			
			$data = array(
				'titulo' => 'Adicionar Fornecedor',
				'styles' => array(
					'vendor/datatables/dataTables.bootstrap4.min.css',
				),
				'scripts' => array(
					'js/app.js',
					'js/jquery.mask.min.js'
				),
				
			);	
			
		
		
		
			$this->load->view('_includes/header', $data);
			$this->load->view('fornecedores/add');
			$this->load->view('_includes/footer');
		
		}
	}
	
	
	public function edit($fornecedor_id = NULL){
		
		if(!$fornecedor_id || !$this->Core_model->get_by_id('fornecedores', array('fornecedor_id' => $fornecedor_id))){
			$this->session->set_flashdata('error', 'Fornecedor não existe!');
			redirect('fornecedor');
		}else{
			
			$this->form_validation->set_rules('fornecedor_razao', '', 'trim|max_length[145]');
			$this->form_validation->set_rules('fornecedor_nome_fantasia', '', 'trim|required|max_length[80]');
			$this->form_validation->set_rules('fornecedor_cnpj', '', 'exact_length[18]|callback_valida_cnpj');
			
			$this->form_validation->set_rules('fornecedor_ie', '', 'trim|max_length[20]');
			$this->form_validation->set_rules('fornecedor_email', '', 'trim|valid_email|max_length[80]');
			$this->form_validation->set_rules('fornecedor_telefone', '', 'trim|max_length[15]');
			$this->form_validation->set_rules('fornecedor_celular', '', 'trim|required|max_length[15]');
			$this->form_validation->set_rules('fornecedor_contato', '', 'trim|max_length[25]');
			$this->form_validation->set_rules('fornecedor_cep', '', 'trim|exact_length[9]');
			$this->form_validation->set_rules('fornecedor_endereco', '', 'trim|required|max_length[80]');
			$this->form_validation->set_rules('fornecedor_numero_endereco', '', 'trim|required|max_length[10]');
			$this->form_validation->set_rules('fornecedor_bairro', '', 'trim|required|max_length[45]');
			$this->form_validation->set_rules('fornecedor_complemento', '', 'trim|max_length[45]');
			
			$this->form_validation->set_rules('fornecedor_cidade', '', 'trim|required|max_length[45]');
			$this->form_validation->set_rules('fornecedor_estado', '', 'trim|required|exact_length[2]');
			$this->form_validation->set_rules('fornecedor_obs', '', 'max_length[500]');					
								
			if($this->form_validation->run()){
				
				$fornecedor_ativo = $this->input->post('fornecedor_ativo');
				
				if($this->db->table_exists('produtos')){
					 if($fornecedor_ativo == 2 && $this->Core_model->get_by_id('produtos', array('produto_fornecedor_id' => $fornecedor_id, 'produto_ativo' =>1))){
						$this->session->set_flashdata('error', 'Este fornecedor não pode ser desativado, pois está sendo utilizada em Produtos');					 				redirect('fornecedor');
					 }
				}
				
				$data = elements(
					array(
					 	'fornecedor_ativo',
						'fornecedor_razao',
						'fornecedor_nome_fantasia',
						'fornecedor_cnpj',
						'fornecedor_ie',
						'fornecedor_email',
						'fornecedor_telefone',
						'fornecedor_celular',
						'fornecedor_contato',
						'fornecedor_cep',
						'fornecedor_endereco',
						'fornecedor_numero_endereco',
						'fornecedor_bairro',
						'fornecedor_cidade',
						'fornecedor_estado',
						'fornecedor_obs'
					), $this->input->post()
				);
				$data['fornecedor_estado'] = strtoupper($this->input->post('fornecedor_estado'));
				$data = html_escape($data);
			
				$this->Core_model->update('fornecedores', $data, array('fornecedor_id' => $fornecedor_id));
				
				redirect('fornecedor');
				echo 'validado';
			
			}else{
				
				$data = array(
					'titulo' => 'Editar Fornecedor',
					'styles' => array(
						'vendor/datatables/dataTables.bootstrap4.min.css',
					),
					'scripts' => array(
						'js/app.js',
						'js/jquery.mask.min.js'
					),
					
					'fornecedores' => $this->Core_model->get_by_id('fornecedores', array('fornecedor_id' => $fornecedor_id))
				);	
				
			
			
			
				$this->load->view('_includes/header', $data);
				$this->load->view('fornecedores/edit');
				$this->load->view('_includes/footer');
			
			}
			
		}	
		
		
	}
	
	
	public function delete($fornecedor_id = NULL){
		
		if(!$fornecedor_id || !$this->Core_model->get_by_id('fornecedores', array('fornecedor_id' => $fornecedor_id))){
			$this->session->set_flashdata('error', 'Fornecedor não existe!');
			redirect('fornecedor');
		}else{
			$this->Core_model->update('fornecedores', array('fornecedor_ativo' => 2), array('fornecedor_id' => $fornecedor_id));
			redirect('fornecedor');
		}
		
	}
	
	public function valida_cnpj($cnpj) {

        // Verifica se um número foi informado
        if (empty($cnpj)) {
            $this->form_validation->set_message('valida_cnpj', 'Por favor digite um CNPJ válido');
            return false;
        }

        if ($this->input->post('fornecedor_id')) {

            $fornecedor_id = $this->input->post('fornecedor_id');

            if ($this->Core_model->get_by_id('fornecedores', array('fornecedor_id !=' => $fornecedor_id, 'fornecedor_cnpj' => $cnpj))) {
                $this->form_validation->set_message('valida_cnpj', 'Esse CNPJ já existe');
                return FALSE;
            }
        }

        // Elimina possivel mascara
        $cnpj = preg_replace("/[^0-9]/", "", $cnpj);
        $cnpj = str_pad($cnpj, 14, '0', STR_PAD_LEFT);


        // Verifica se o numero de digitos informados é igual a 11 
        if (strlen($cnpj) != 14) {
            $this->form_validation->set_message('valida_cnpj', 'Por favor digite um CNPJ válido');
            return false;
        }

        // Verifica se nenhuma das sequências invalidas abaixo 
        // foi digitada. Caso afirmativo, retorna falso
        else if ($cnpj == '00000000000000' ||
                $cnpj == '11111111111111' ||
                $cnpj == '22222222222222' ||
                $cnpj == '33333333333333' ||
                $cnpj == '44444444444444' ||
                $cnpj == '55555555555555' ||
                $cnpj == '66666666666666' ||
                $cnpj == '77777777777777' ||
                $cnpj == '88888888888888' ||
                $cnpj == '99999999999999') {
            $this->form_validation->set_message('valida_cnpj', 'Por favor digite um CNPJ válido');
            return false;

            // Calcula os digitos verificadores para verificar se o
            // CPF é válido
        } else {

            $j = 5;
            $k = 6;
            $soma1 = "";
            $soma2 = "";

            for ($i = 0; $i < 13; $i++) {

                $j = $j == 1 ? 9 : $j;
                $k = $k == 1 ? 9 : $k;

                //$soma2 += ($cnpj{$i} * $k);

                //$soma2 = intval($soma2) + ($cnpj{$i} * $k); //Para PHP com versão < 7.4
                $soma2 = intval($soma2) + ($cnpj[$i] * $k); //Para PHP com versão > 7.4

                if ($i < 12) {
                    //$soma1 = intval($soma1) + ($cnpj{$i} * $j); //Para PHP com versão < 7.4
                    $soma1 = intval($soma1) + ($cnpj[$i] * $j); //Para PHP com versão > 7.4
                }

                $k--;
                $j--;
            }

            $digito1 = $soma1 % 11 < 2 ? 0 : 11 - $soma1 % 11;
            $digito2 = $soma2 % 11 < 2 ? 0 : 11 - $soma2 % 11;

            if (!($cnpj[12] == $digito1) and ( $cnpj[13] == $digito2)) {
                $this->form_validation->set_message('valida_cnpj', 'Por favor digite um CNPJ válido');
                return false;
            } else {
                return true;
            }
        }
    }

	
	
	
}	