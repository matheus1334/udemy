<?php 

defined('BASEPATH') OR exit ('Ação não permitida.');

Class Os extends CI_Controller{
	
	public function __construct(){
		parent::__construct();
	
		//definir se há sessão
		if(!$this->ion_auth->logged_in()){
			$this->session->set_flashdata('info', 'Sua sessão expirou.');
			redirect('login');
		}
		
		$this->load->model('Ordem_model');
		
	}
	
	public function index(){
		$data = array(
			'titulo' => 'Ordem de Serviços',
			'styles' => array(
				'vendor/datatables/dataTables.bootstrap4.min.css',
			),
			'scripts' => array(
				'vendor/datatables/jquery.dataTables.min.js',
				'vendor/datatables/dataTables.bootstrap4.min.js',
				'vendor/datatables/app.js',
			),
			'ordens_servicos' => $this->Ordem_model->get_all(),
		);
		
			$this->load->view('_includes/header', $data);
			$this->load->view('os/index');
			$this->load->view('_includes/footer');
	}
	
	public function add(){
		

		$this->form_validation->set_rules('ordem_servico_cliente_id', '','required');
		
		$this->form_validation->set_rules('ordem_servico_valor_total', '','required');
	
		
		if($this->form_validation->run()){
			$ordem_servico_valor_total = str_replace('R$', '', trim($this->input->post('ordem_servico_valor_total')));
			
			$data = elements(
				array(
					'ordem_servico_cliente_id',
					'ordem_servico_forma_pagamento_id',
					'ordem_servico_status',
					'ordem_servico_obs',
					'ordem_servico_valor_desconto',
					'ordem_servico_valor_total',
				),$this->input->post()
			);
			
			if($ordem_servico_status == 0){
				unset($data['ordem_servico_forma_pagamento_id']);
			}
			
			$data['ordem_servico_valor_total'] = trim(preg_replace('/\$/', '', $ordem_servico_valor_total));
			$data = html_escape($data);
			
			$this->Core_model->insert('ordens_servicos', $data, TRUE);
			// O TRUE ELE RECUPERA O ULTIMO ID E ARMAZENA EM SESSÃO
			// O TRUE FOI DEFINIDO EM CORE MODEL ANTECIPAMENTE
			
			$id_ordem_servico = $this->session->userdata('last_id');
			
			
			
			$servico_id = $this->input->post('servico_id');
			$servico_quantidade = $this->input->post('servico_quantidade');
			$servico_desconto = str_replace('%', '', $this->input->post('servico_desconto'));
			
			$servico_preco = str_replace('R$', '',  $this->input->post('servico_preco'));
			$servico_item_total = str_replace('R$', '',  $this->input->post('servico_item_total'));
			$servico_preco = str_replace(',', '', $servico_preco);
			$servico_item_total = str_replace(',', '',  $servico_item_total);
			
						 
			$qty_servico = count($servico_id);
			
			$ordem_servico_id = $this->input->post('ordem_servico_id');
			
			for($i = 0; $i < $qty_servico; $i++){
				
				$data = array(
					'ordem_ts_id_ordem_servico' => $id_ordem_servico,
					'ordem_ts_id_servico' => $servico_id[$i],
					'ordem_ts_quantidade' => $servico_quantidade[$i],
					'ordem_ts_servico_descricao_servico' => $descricao_servico[$i],
					'ordem_ts_valor_unitario' => $servico_preco[$i],
					'ordem_ts_valor_desconto' => $servico_desconto[$i],
					'ordem_ts_valor_total' => $servico_item_total[$i],
				);
				
				$data = html_escape($data);
				$this->Core_model->insert('ordem_tem_servicos', $data);
				
			}
			
			// criar recurso pdf
			
			redirect('os/imprimir/'.$id_ordem_servico);
			//echo '<pre>'; print_r($this->input->post());  exit();
			
			
		}else{
			
			$data = array(
			'titulo' => 'Cadastrar Ordem de Serviços',
			'styles' => array(
				'js/select/select2.min.css',
				'vendor/autocomplete/jquery-ui.css',
				'vendor/autocomplete/estilo.css',
			),
			'scripts' => array(
				'vendor/autocomplete/jquery-migrate.js',
				'vendor/calcx/jquery-calx-sample-2.2.8.min.js',
				'vendor/calcx/os.js',
				'js/select/select2.min.js',
				'js/select/custom.js',
				'vendor/sweetalert2/sweetalert2.js',
				'vendor/autocomplete/jquery-ui.js',
			),
			'clientes' => $this->Core_model->get_all('clientes', array('cliente_ativo' => 1)),
			'formas_pagamentos' => $this->Core_model->get_all('formas_pagamentos', array('forma_pagamento_ativa' => 1)),
			);
		
			
			$this->load->view('_includes/header', $data);
			$this->load->view('os/add');
			$this->load->view('_includes/footer');	
			
		}
	
		
	}
	
	
	public function edit($ordem_servico_id = NULL){
		
		if(!$ordem_servico_id || !$this->Core_model->get_by_id('ordens_servicos', array('ordem_servico_id' => $ordem_servico_id))){
			$this->session->set_flashdata('error', 'Ordem de Serviço não existe!');
			redirect('os');
		}else{
			
			$this->form_validation->set_rules('ordem_servico_cliente_id', '','required');
			
			$this->form_validation->set_rules('ordem_servico_valor_total', '','required');
		
			
			if($this->form_validation->run()){
				$ordem_servico_valor_total = str_replace('R$', '', trim($this->input->post('ordem_servico_valor_total')));
				
				$data = elements(
					array(
						'ordem_servico_cliente_id',
						'ordem_servico_forma_pagamento_id',
						'ordem_servico_status',
						'ordem_servico_obs',
						'ordem_servico_valor_desconto',
						'ordem_servico_valor_total',
					),$this->input->post()
				);
				if($ordem_servico_status == 0){
					unset($data['ordem_servico_forma_pagamento_id']);
				}
				$data['ordem_servico_valor_total'] = trim(preg_replace('/\$/', '', $ordem_servico_valor_total));
				$data = html_escape($data);
				
				$this->Core_model->update('ordens_servicos', $data, array('ordem_servico_id' => $ordem_servico_id));
				
				// deletando de ordem_tem_servico, os serviços antigos da ordem editada
				 
				$this->Ordem_model->delete_old_services($ordem_servico_id);
				$servico_id = $this->input->post('servico_id');
				$servico_quantidade = $this->input->post('servico_quantidade');
				$servico_desconto = str_replace('%', '', $this->input->post('servico_desconto'));
				
				$servico_preco = str_replace('R$', '',  $this->input->post('servico_preco'));
				$servico_item_total = str_replace('R$', '',  $this->input->post('servico_item_total'));
				$servico_preco = str_replace(',', '', $servico_preco);
				$servico_item_total = str_replace(',', '',  $servico_item_total);
				$descricao_servico = $this->input->post('descricao_servico');
							 
				$qty_servico = count($servico_id);
				
				$ordem_servico_id = $this->input->post('ordem_servico_id');
				
				for($i = 0; $i < $qty_servico; $i++){
					
					$data = array(
						'ordem_ts_id_ordem_servico' => $ordem_servico_id,
						'ordem_ts_id_servico' => $servico_id[$i],
						'ordem_ts_servico_descricao_servico' => $descricao_servico[$i],
						'ordem_ts_quantidade' => $servico_quantidade[$i],
						'ordem_ts_valor_unitario' => $servico_preco[$i],
						'ordem_ts_valor_desconto' => $servico_desconto[$i],
						'ordem_ts_valor_total' => $servico_item_total[$i],
					);
					
			//		echo '<pre>'; print_r($data); exit();
					
					$data = html_escape($data);
					$this->Core_model->insert('ordem_tem_servicos', $data);
					
				}
				
				// criar recurso pdf
				
				redirect('os/imprimir/'.$ordem_servico_id);
				//echo '<pre>'; print_r($this->input->post());  exit();
				
				
			}else{
				
				$data = array(
				'titulo' => 'Ordem de Serviços',
				'styles' => array(
					'js/select/select2.min.css',
					'vendor/autocomplete/jquery-ui.css',
					'vendor/autocomplete/estilo.css',
				),
				'scripts' => array(
					'vendor/autocomplete/jquery-migrate.js',
					'vendor/calcx/jquery-calx-sample-2.2.8.min.js',
					'vendor/calcx/os.js',
					'js/select/select2.min.js',
					'js/select/custom.js',
					'vendor/sweetalert2/sweetalert2.js',
					'vendor/autocomplete/jquery-ui.js',
				),
				'clientes' => $this->Core_model->get_all('clientes', array('cliente_ativo' => 1)),
				'formas_pagamentos' => $this->Core_model->get_all('formas_pagamentos', array('forma_pagamento_ativa' => 1)),
				'os_tem_servicos' => $this->Ordem_model->get_all_servico_by_ordem($ordem_servico_id),
				);
			
				$ordem_servico = $data['ordem_servico'] = $this->Ordem_model->get_by_id($ordem_servico_id);
				 
				
				$this->load->view('_includes/header', $data);
				$this->load->view('os/edit');
				$this->load->view('_includes/footer');	
				
			}
		}
		
	}
	
	public function imprimir($ordem_servico_id = NULL){
		
		if(!$ordem_servico_id || !$this->Core_model->get_by_id('ordens_servicos', array('ordem_servico_id' => $ordem_servico_id))){
			$this->session->set_flashdata('error', 'Ordem de Serviço não existe!');
			redirect('os');
		}else{
			
			$data = array(
				'titulo' => 'Escolha uma opção',
				'ordem_servico' => $this->Core_model->get_by_id('ordens_servicos', array('ordem_servico_id' => $ordem_servico_id)),
			);
			 
			$this->load->view('_includes/header', $data);
			$this->load->view('os/imprimir');
			$this->load->view('_includes/footer');	
			
		}
	}
	
	
		
	public function pdf($ordem_servico_id = NULL){
		
		if(!$ordem_servico_id || !$this->Core_model->get_by_id('ordens_servicos', array('ordem_servico_id' => $ordem_servico_id))){
			$this->session->set_flashdata('error', 'Ordem de Serviço não existe!');
			redirect('os');
		}else{
			
			$empresa = $this->Core_model->get_by_id('sistema', array('sistema_id' => 1));
			$ordem_servico = $this->Ordem_model->get_by_id($ordem_servico_id);
			
			
			$file_name = 'O.S&nbsp;'.$ordem_servico->ordem_servico_id ;
			
			$html = '<html>';
			$html .= '<head><title>'.$empresa->sistema_nome_fantasia.' - Impressão de OS</title></head>';
			$html .= '<body style="font-size: 14px; font-family: Arial, Helvetica, sans-serif;">';
			$html .= '<h4 align="center">
					Razão Social: '.$empresa->sistema_razao_social.'<br>
					CNPJ: '.$empresa->sistema_cnpj.'<br>
					Whatsapp: '.$empresa->sistema_telefone_movel.'<br>
					E-mail: '.$empresa->sistema_email.'<br>
					Site: '.$empresa->sistema_site_url.'
					  </h4> <hr>';
			
			
			$html .= '<p style="text-align: right;">Nº '.$ordem_servico->ordem_servico_id.'</p>';
			$html .= '<p>
				Cliente: '.$ordem_servico->cliente_nome_completo.' <br>
				CPF/CNPJ: '.$ordem_servico->cliente_cpf_cnpj.' <br>
				Celular: '.$ordem_servico->cliente_celular.' <br>
				Data de Emissão: ' .formata_data_banco_sem_hora($ordem_servico->ordem_servico_data_emissao). ' <br>
				Forma Pagamento: '.($ordem_servico->ordem_servico_status == 1 ? $ordem_servico->forma_pagamento_nome : 'Em aberto').'				
			</p>';
			$html .= '<hr>';
			$html .= '<table width="100%">';
			$html .= '<tr><th>Serviço</th><th>Descrição</th><th style="text-align: center;">QTD</th><th style="text-align: center;">R$ unitário</th><th style="text-align: center;">R$  Total</th></tr>';
			$ordem_servico_id = $ordem_servico->ordem_servico_id;
			$servicos_ordem = $this->Ordem_model->get_all_servicos($ordem_servico_id);
			$valor_final_os = $this->Ordem_model->get_valor_final_os($ordem_servico_id);
			
			foreach($servicos_ordem as $servico){
				
				$html .= '<tr>';
				$html .= '<td>'.$servico->servico_nome.'</td>';
				$html .= '<td>'.$servico->ordem_ts_servico_descricao_servico.'</td>';
				$html .= '<td style="text-align: center;">'.$servico->ordem_ts_quantidade.'</td>';
				$html .= '<td style="text-align: center;">R$ '.$servico->ordem_ts_valor_unitario.'</td>';
				/*$html .= '<td>'.$servico->ordem_ts_valor_desconto.'</td>';*/
				$html .= '<td style="text-align: center;">R$ '.$servico->ordem_ts_valor_total.'</td>';
				
				$html .= '</tr>';
			}
			
			
			$html .= '<tr  style="background: #eee;">';
			$html .= '<th colspan="4"  style="text-align: right; padding-right: 10px; padding-top: 10px; padding-bottom: 10px;">Valor Total:</th>';
			$html .= '<th style="text-align: right; padding-right: 10px; padding-left: 10px;  padding-top: 10px; padding-bottom: 10px;"> R$ '.$valor_final_os->os_valor_total.'</th>';
			$html .= '</tr>';
			$html .= '</table>';
			
			
			
			$html .= '</body></html>';
		
			// FALSE  ABRE O PDF NO NAVEGADOR
			// TRUE FAZ O DOWNLOAD
			
			$this->pdf->createPDF($html, $file_name, false);	
			
		}
	}



	public function delete($ordem_servico_id = NULL){
		if(!$ordem_servico_id || !$this->Core_model->get_by_id('ordens_servicos', array('ordem_servico_id' => $ordem_servico_id))){
			$this->session->set_flashdata('error', 'Ordem de Serviço não existe!');
			redirect('os');
		}
		
		if($this->Core_model->get_by_id('ordens_servicos', array('ordem_servico_id' => $ordem_servico_id, 'ordem_servico_status' => 0))){
			$this->session->set_flashdata('error', 'Não é possível excluír uma ordem de serviço em aberto!');
			redirect('os');
		}
		
		$this->Core_model->delete('ordens_servicos', array('ordem_servico_id' => $ordem_servico_id));
		redirect('os');
		
	}
		
}