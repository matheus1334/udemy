<?php 

defined('BASEPATH') OR exit ('Ação não permitida.');

Class Produto extends CI_Controller{
	
	public function __construct(){
		parent::__construct();
	
		//definir se há sessão
		if(!$this->ion_auth->logged_in()){
			$this->session->set_flashdata('info', 'Sua sessão expirou.');
			redirect('login');
		}
		
		$this->load->model('produtos_model');
		
	}
	
	public function index(){
		$data = array(
			'titulo' => 'Produtos Cadastrados',
			'styles' => array(
				'vendor/datatables/dataTables.bootstrap4.min.css',
			),
			'scripts' => array(
				'vendor/datatables/jquery.dataTables.min.js',
				'vendor/datatables/dataTables.bootstrap4.min.js',
				'vendor/datatables/export/dataTables.buttons.min.j',
				'vendor/datatables/export/pdfmake.min.js',
				'vendor/datatables/export/vfs_fonts.js',
				'vendor/datatables/export/buttons.html5.min.js',
				
				'vendor/datatables/app.js',
			),
			'produtos' => $this->produtos_model->get_all(),
		);
			
		
			$this->load->view('_includes/header', $data);
			$this->load->view('produtos/index');
			$this->load->view('_includes/footer');
	}
	public function add(){
		$this->form_validation->set_rules('produto_descricao', '', 'trim|required|min_length[4]|is_unique[produtos.produto_descricao]');
		$this->form_validation->set_rules('produto_preco_custo', 'Preço de Custo', 'trim|required');
		$this->form_validation->set_rules('produto_preco_venda', 'Preço de Venda', 'trim|required|callback_check_produto_preco_venda');
		$this->form_validation->set_rules('produto_estoque_minimo', '', 'trim|required|greater_than_equal_to[0]');
		$this->form_validation->set_rules('produto_qtde_estoque', '', 'trim|required');
		$this->form_validation->set_rules('produto_obs', '', 'max_length[500]');
		
		
		if($this->form_validation->run()){
			$data = elements(
				array(
					'produto_codigo',
					'produto_categoria_id',
					'produto_marca_id',
					'produto_fornecedor_id',
					'produto_descricao',
					'produto_unidade',
					'produto_preco_custo',
					'produto_preco_venda',
					'produto_estoque_minimo',
					'produto_qtde_estoque',
					'produto_ativo',
					'produto_obs'
				), $this->input->post()
			);
			
			
			$data = html_escape($data);
			$this->Core_model->insert('produtos', $data);
			
			redirect('produto');
			
		}else{
			$data = array(
				'titulo' => 'Cadastrar Produto',
				'scripts' => array(
					'js/app.js',
					'js/jquery.mask.min.js'
				),
				'produto_codigo' => $this->Core_model->generate_unique_code('produtos', 'numeric', 8, 'produto_codigo'), 
 				'marcas' => $this->Core_model->get_all('marcas', array('marca_ativa' => 1)),
				'categorias' => $this->Core_model->get_all('categorias', array('categoria_ativa' => 1)),
				'fornecedores' => $this->Core_model->get_all('fornecedores', array('fornecedor_ativo' => 1)),
			);	
		
			$this->load->view('_includes/header', $data);
			$this->load->view('produtos/add');
			$this->load->view('_includes/footer');
		}	
	}
	
	public function edit($produto_id = NULL){
		if(!$produto_id || !$this->Core_model->get_by_id('produtos', array('produto_id' => $produto_id))){
			$this->session->set_flashdata('error', 'Produto não encontrado');
			redirect('produto');
		}else{
			
			$this->form_validation->set_rules('produto_descricao', '', 'trim|required|min_length[4]|callback_check_produto_descricao');
			$this->form_validation->set_rules('produto_preco_custo', 'Preço de Custo', 'trim|required');
			$this->form_validation->set_rules('produto_preco_venda', 'Preço de Venda', 'trim|required|callback_check_produto_preco_venda');
			$this->form_validation->set_rules('produto_estoque_minimo', '', 'trim|required|greater_than_equal_to[0]');
			$this->form_validation->set_rules('produto_qtde_estoque', '', 'trim|required');
			$this->form_validation->set_rules('produto_obs', '', 'max_length[500]');
			
			
			if($this->form_validation->run()){
				$data = elements(
					array(
						'produto_codigo',
						'produto_categoria_id',
						'produto_marca_id',
						'produto_fornecedor_id',
						'produto_descricao',
						'produto_unidade',
						'produto_preco_custo',
						'produto_preco_venda',
						'produto_estoque_minimo',
						'produto_qtde_estoque',
						'produto_ativo',
						'produto_obs'
					), $this->input->post()
				);
				
				
				$data = html_escape($data);
				$this->Core_model->update('produtos', $data, array('produto_id' => $produto_id));
				
				redirect('produto');
				
			}else{
				$data = array(
					'titulo' => 'Editar Produto',
					'scripts' => array(
						'js/app.js',
						'js/jquery.mask.min.js'
					),
					
					'produtos' => $this->Core_model->get_by_id('produtos', array('produto_id' => $produto_id)),
					'marcas' => $this->Core_model->get_all('marcas'),
					'categorias' => $this->Core_model->get_all('categorias'),
					'fornecedores' => $this->Core_model->get_all('fornecedores'),
				);	
			
				$this->load->view('_includes/header', $data);
				$this->load->view('produtos/edit');
				$this->load->view('_includes/footer');
			}	
		}
	}
	
	
	public function delete($produto_id = NULL){
		
		if(!$produto_id || !$this->Core_model->get_by_id('produtos', array('produto_id' => $produto_id))){
			$this->session->set_flashdata('error', 'Produto não existe!');
			redirect('produto');
		}else{
			$this->Core_model->update('produtos', array('produto_ativo' => 2), array('produto_id' => $produto_id));
			redirect('produto');
		}
		
	}
	
	
	
	public function check_produto_descricao($produto_descricao){
		$produto_id = $this->input->post('produto_id');
		
		if($this->Core_model->get_by_id('produtos', array('produto_descricao' => $produto_descricao, 'produto_id !=' => $produto_id))){
			
			$this->form_validation->set_message('check_produto_descricao', 'Esse produto já existe');
			return FALSE;
		}else{
			return TRUE;
		}
	}
	
	
	public function check_produto_preco_venda($produto_preco_venda){
		$produto_preco_custo = $this->input->post('produto_preco_custo');
		
		
		$produto_preco_custo = str_replace('.', '', $produto_preco_custo);
		$produto_preco_venda = str_replace('.', '', $produto_preco_venda);
		
		$produto_preco_custo = str_replace(',', '', $produto_preco_custo);
		$produto_preco_venda = str_replace(',', '', $produto_preco_venda);
		
		
		if($produto_preco_custo > $produto_preco_venda){
			
			$this->form_validation->set_message('check_produto_preco_venda', 'Preço de venda deve ser igual ou maior que o preço de custo');
			return FALSE;
		}else{
			return TRUE;
		}
	}
}